#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generate the original, fan-made Blue Archive inspired artwork used by the
affection calculator. Everything is drawn from primitives so the app has no
external image dependencies.
"""
from __future__ import annotations

import math
import os
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "assets"
OUT.mkdir(parents=True, exist_ok=True)

NAVY = (37, 51, 78, 255)
NAVY_SOFT = (52, 72, 108, 255)
CREAM = (255, 250, 238, 255)
CREAM_DARK = (246, 236, 215, 255)
GOLD = (247, 197, 86, 255)
GOLD_DARK = (214, 151, 44, 255)
GOLD_LIGHT = (255, 227, 137, 255)
BLUE = (70, 156, 228, 255)
BLUE_DARK = (42, 105, 184, 255)
BLUE_LIGHT = (147, 215, 249, 255)
PINK = (245, 135, 168, 255)
PINK_DARK = (204, 84, 128, 255)
MINT = (105, 199, 177, 255)
MINT_DARK = (49, 141, 128, 255)
PURPLE = (163, 132, 224, 255)
PURPLE_DARK = (104, 78, 174, 255)
PURPLE_LIGHT = (212, 192, 250, 255)
WHITE = (255, 255, 255, 255)
INK = (32, 44, 68, 255)


def S(v: float, scale: int = 2) -> int:
    return int(round(v * scale))


def canvas(size: int, scale: int = 2) -> Image.Image:
    return Image.new("RGBA", (size * scale, size * scale), (0, 0, 0, 0))


def downsample(img: Image.Image, size: int) -> Image.Image:
    return img.resize((size, size), Image.Resampling.LANCZOS)


def vertical_gradient(mask: Image.Image, top, bottom) -> Image.Image:
    w, h = mask.size
    y = np.linspace(0.0, 1.0, h, dtype=np.float32)[:, None, None]
    top_arr = np.array(top[:3], dtype=np.float32)[None, None, :]
    bottom_arr = np.array(bottom[:3], dtype=np.float32)[None, None, :]
    rgb = top_arr * (1.0 - y) + bottom_arr * y
    rgb = np.repeat(rgb, w, axis=1)
    alpha = np.array(mask, dtype=np.float32)[..., None]
    rgba = np.concatenate([rgb, alpha], axis=2)
    return Image.fromarray(np.clip(rgba, 0, 255).astype(np.uint8), "RGBA")


def fill_round_gradient(img, box, radius, top, bottom, outline=NAVY, width=8):
    layer = Image.new("L", img.size, 0)
    d = ImageDraw.Draw(layer)
    d.rounded_rectangle(box, radius=radius, fill=255)
    grad = vertical_gradient(layer, top, bottom)
    img.alpha_composite(grad)
    d2 = ImageDraw.Draw(img)
    d2.rounded_rectangle(box, radius=radius, outline=outline, width=width)


def shadow(img, box, radius, offset=(0, 18), blur=18, alpha=90):
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.rounded_rectangle(
        (box[0] + offset[0], box[1] + offset[1], box[2] + offset[0], box[3] + offset[1]),
        radius=radius,
        fill=(23, 34, 58, alpha),
    )
    layer = layer.filter(ImageFilter.GaussianBlur(blur))
    img.alpha_composite(layer)


def sparkle(draw, x, y, r, color=GOLD, outline=None, width=0):
    pts = [
        (x, y - r),
        (x + r * 0.24, y - r * 0.24),
        (x + r, y),
        (x + r * 0.24, y + r * 0.24),
        (x, y + r),
        (x - r * 0.24, y + r * 0.24),
        (x - r, y),
        (x - r * 0.24, y - r * 0.24),
    ]
    draw.polygon(pts, fill=color, outline=outline)
    if width:
        draw.line(pts + [pts[0]], fill=outline, width=width)


def halo(img, cx, cy, rx, ry, color=(255, 216, 109, 255), width=28, angle=0):
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.ellipse((cx - rx, cy - ry, cx + rx, cy + ry), outline=color, width=width)
    # a small gap + star gives the halo a game-like, hand-drawn feel
    layer = layer.rotate(angle, center=(cx, cy), resample=Image.Resampling.BICUBIC)
    img.alpha_composite(layer)


def draw_bow(draw, cx, cy, w, h, fill, outline, width, inner=None):
    """A chunky ribbon bow made from two soft leaf shapes."""
    left = [
        (cx - 8, cy + 8),
        (cx - w * 0.62, cy - h * 0.54),
        (cx - w * 0.84, cy - h * 0.10),
        (cx - w * 0.72, cy + h * 0.35),
        (cx - w * 0.40, cy + h * 0.44),
        (cx - 10, cy + 16),
    ]
    right = [
        (cx + 8, cy + 8),
        (cx + w * 0.62, cy - h * 0.54),
        (cx + w * 0.84, cy - h * 0.10),
        (cx + w * 0.72, cy + h * 0.35),
        (cx + w * 0.40, cy + h * 0.44),
        (cx + 10, cy + 16),
    ]
    draw.polygon(left, fill=fill, outline=outline)
    draw.line(left + [left[0]], fill=outline, width=width, joint="curve")
    draw.polygon(right, fill=fill, outline=outline)
    draw.line(right + [right[0]], fill=outline, width=width, joint="curve")
    if inner:
        for side in (-1, 1):
            pts = []
            for t in range(24):
                a = math.pi * (0.25 + 0.9 * t / 23)
                px = cx + side * (22 + w * 0.30 * math.cos(a))
                py = cy - 4 + h * 0.22 * math.sin(a)
                pts.append((px, py))
            draw.line(pts, fill=inner, width=max(3, width // 2), joint="curve")
    draw.ellipse((cx - 24, cy - 10, cx + 24, cy + 38), fill=fill, outline=outline, width=width)
    draw.arc((cx - 12, cy - 4, cx + 12, cy + 20), 200, 340, fill=inner or outline, width=max(3, width // 3))


def gift_box(img, draw, x, y, w, h, body_top, body_bottom, ribbon, face="smile", outline=NAVY, ow=12, shadow_on=True):
    """Draw a front-facing present. (x,y) is the top-left of the body."""
    S_ = 1.0
    if shadow_on:
        shadow(img, (x, y, x + w, y + h), int(w * 0.08), offset=(0, int(h * 0.07)), blur=int(w * 0.045), alpha=80)

    # ribbon behind the lid (the vertical band is visible under the bow)
    draw.rounded_rectangle((x + w * 0.39, y - h * 0.02, x + w * 0.61, y + h), radius=int(w * 0.025), fill=ribbon, outline=outline, width=ow)
    # body
    fill_round_gradient(img, (x, y, x + w, y + h), int(w * 0.075), body_top, body_bottom, outline, ow)
    draw.rounded_rectangle((x + w * 0.39, y + h * 0.06, x + w * 0.61, y + h * 0.97), radius=int(w * 0.02), fill=ribbon, outline=outline, width=ow)
    # ribbon highlight / shadow strips
    draw.rounded_rectangle((x + w * 0.405, y + h * 0.08, x + w * 0.475, y + h * 0.93), radius=int(w * 0.02), fill=(255, 242, 190, 110))
    draw.rounded_rectangle((x + w * 0.545, y + h * 0.08, x + w * 0.59, y + h * 0.93), radius=int(w * 0.02), fill=(126, 78, 17, 60))
    # lid
    lx, ly, lw, lh = x - w * 0.055, y - h * 0.16, w * 1.11, h * 0.23
    fill_round_gradient(img, (lx, ly, lx + lw, ly + lh), int(w * 0.055), body_top, body_bottom, outline, ow)
    draw.rounded_rectangle((lx + lw * 0.405, ly + 2, lx + lw * 0.595, ly + lh - 2), radius=int(w * 0.02), fill=ribbon, outline=outline, width=ow)
    draw.rounded_rectangle((lx + lw * 0.405, ly + 8, lx + lw * 0.465, ly + lh - 8), radius=int(w * 0.015), fill=(255, 242, 190, 120))
    # bow
    draw_bow(draw, x + w * 0.5, y - h * 0.19, w * 0.52, h * 0.27, ribbon, outline, ow, inner=(255, 236, 164, 150))
    # face
    if face != "none":
        ex = w * 0.22
        ey = h * 0.44
        eye_r = w * 0.028
        for sx in (-1, 1):
            draw.ellipse((x + w * 0.5 + sx * ex - eye_r, y + ey - eye_r * 1.4,
                          x + w * 0.5 + sx * ex + eye_r, y + ey + eye_r * 1.4), fill=outline)
        if face == "smile":
            draw.arc((x + w * 0.44, y + ey, x + w * 0.56, y + ey + h * 0.14), 15, 165, fill=outline, width=max(4, int(w * 0.018)))
        elif face == "big":
            draw.arc((x + w * 0.40, y + ey - h * 0.01, x + w * 0.60, y + ey + h * 0.22), 8, 172, fill=outline, width=max(5, int(w * 0.024)))
            draw.ellipse((x + w * 0.44, y + ey + h * 0.12, x + w * 0.56, y + ey + h * 0.20), fill=PINK)
        elif face == "heart":
            hx, hy, hr = x + w * 0.5, y + h * 0.50, w * 0.10
            draw.polygon([
                (hx, hy + hr), (hx - hr, hy - hr * 0.05),
                (hx - hr * 0.58, hy - hr * 0.62), (hx, hy - hr * 0.18),
                (hx + hr * 0.58, hy - hr * 0.62), (hx + hr, hy - hr * 0.05),
            ], fill=PINK, outline=outline)
    # little highlights
    draw.arc((x + w * 0.10, y + h * 0.15, x + w * 0.36, y + h * 0.50), 190, 280, fill=(255, 255, 255, 140), width=max(4, int(w * 0.02)))


def face_icon(name: str, body_a, body_b, ribbon, face, accent):
    size = 512
    scale = 2
    img = canvas(size, scale)
    d = ImageDraw.Draw(img)
    # rounded pastel tile + dotted corner
    fill_round_gradient(img, (S(30), S(30), S(482), S(482)), S(80), CREAM, CREAM_DARK, NAVY, S(7))
    # diagonal stripes, clipped by hand-drawn triangle
    for i in range(-2, 8):
        x = S(80 + i * 70)
        d.line((x, S(110), x + S(250), S(455)), fill=accent, width=S(10))
    # a soft halo dot field
    for i in range(9):
        a = (i * 0.7) % (2 * math.pi)
        px = S(256) + math.cos(a) * S(158)
        py = S(236) + math.sin(a) * S(135)
        d.ellipse((px - S(4), py - S(4), px + S(4), py + S(4)), fill=(255, 255, 255, 120))
    gift_box(img, d, S(112), S(196), S(288), S(230), body_a, body_b, ribbon, face, NAVY, S(9))
    for (sx, sy, sr, col) in [(S(105), S(120), S(24), GOLD), (S(408), S(160), S(14), PINK), (S(430), S(365), S(21), GOLD)]:
        sparkle(d, sx, sy, sr, col, NAVY, S(4))
    return downsample(img, size)


def make_app_icon():
    size = 1024
    scale = 2
    img = canvas(size, scale)
    d = ImageDraw.Draw(img)
    # paper tile
    shadow(img, (S(42), S(46), S(982), S(986)), S(210), offset=(0, S(16)), blur=S(18), alpha=95)
    fill_round_gradient(img, (S(34), S(34), S(990), S(990)), S(218), (255, 252, 244, 255), (247, 237, 218, 255), NAVY, S(18))
    # diagonal fan stripes in the top right
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    od = ImageDraw.Draw(overlay)
    for i in range(7):
        x = S(610 + i * 72)
        od.line((x, S(40), x + S(300), S(340)), fill=(125, 200, 235, 90), width=S(26))
    mask = Image.new("L", img.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle((S(34), S(34), S(990), S(990)), radius=S(218), fill=255)
    img.alpha_composite(Image.composite(overlay, Image.new("RGBA", img.size, (0, 0, 0, 0)), mask))
    # halo
    halo(img, S(512), S(482), S(350), S(110), (255, 215, 105, 255), S(30), -10)
    halo(img, S(512), S(482), S(286), S(78), (255, 239, 186, 160), S(8), -10)
    for sx, sy, sr, col in [(S(210), S(292), S(26), GOLD), (S(815), S(324), S(18), PINK), (S(835), S(676), S(28), GOLD), (S(210), S(730), S(17), BLUE)]:
        sparkle(d, sx, sy, sr, col, NAVY, S(5))
    # box - bolder than the item art for tiny-taskbar legibility
    gift_box(img, d, S(256), S(534), S(512), S(332), (125, 208, 248, 255), (46, 127, 210, 255), GOLD, "heart", NAVY, S(15), True)
    # small tag on the right
    d.rounded_rectangle((S(746), S(616), S(876), S(752)), radius=S(28), fill=(255, 245, 218, 255), outline=NAVY, width=S(10))
    d.ellipse((S(796), S(646), S(830), S(680)), fill=(255, 255, 255, 255), outline=NAVY, width=S(6))
    d.line((S(746), S(652), S(700), S(628)), fill=NAVY, width=S(8))
    # tiny gloss
    d.arc((S(312), S(590), S(470), S(760)), 200, 292, fill=(255, 255, 255, 155), width=S(12))
    return downsample(img, size)


def make_hero():
    size = 900
    scale = 2
    img = canvas(size, scale)
    d = ImageDraw.Draw(img)
    # soft cream back-plate / window
    plate = Image.new("RGBA", img.size, (0, 0, 0, 0))
    pd = ImageDraw.Draw(plate)
    pd.ellipse((S(78), S(86), S(824), S(806)), fill=(255, 249, 235, 40), outline=(255, 255, 255, 75), width=S(5))
    img.alpha_composite(plate)
    halo(img, S(460), S(365), S(300), S(98), (255, 219, 117, 180), S(21), -9)
    # back small purple gift
    gift_box(img, d, S(160), S(530), S(250), S(186), (200, 174, 246, 255), (137, 104, 205, 255), (255, 224, 153, 255), "big", NAVY, S(8))
    # front main gift
    gift_box(img, d, S(330), S(475), S(365), S(274), (245, 252, 255, 255), (177, 218, 245, 255), (255, 197, 105, 255), "smile", NAVY, S(10))
    # floating heart balloon
    bx, by = S(700), S(196)
    d.line((bx, by + S(76), bx - S(22), by + S(208)), fill=NAVY, width=S(4))
    d.ellipse((bx - S(40), by, bx + S(40), by + S(80)), fill=(255, 154, 181, 255), outline=NAVY, width=S(7))
    d.polygon([(bx - S(38), by + S(58)), (bx, by + S(96)), (bx + S(38), by + S(58))], fill=(255, 154, 181, 255), outline=NAVY)
    d.arc((bx - S(24), by + S(12), bx + S(10), by + S(44)), 190, 300, fill=(255, 255, 255, 160), width=S(5))
    # paper plane
    plane = [(S(98), S(198)), (S(320), S(108)), (S(236), S(246)), (S(208), S(226)), (S(190), S(298)), (S(168), S(246))]
    d.polygon(plane, fill=(236, 250, 255, 255), outline=NAVY)
    d.line(plane + [plane[0]], fill=NAVY, width=S(6), joint="curve")
    d.line((S(236), S(246), S(320), S(108)), fill=(96, 171, 220, 255), width=S(4))
    d.line((S(208), S(226), S(298), S(186)), fill=(96, 171, 220, 255), width=S(3))
    for sx, sy, sr, col in [(S(130), S(390), S(22), GOLD), (S(760), S(525), S(20), PINK), (S(806), S(380), S(14), GOLD), (S(276), S(392), S(12), BLUE)]:
        sparkle(d, sx, sy, sr, col, NAVY, S(4))
    # small dots
    for i in range(18):
        a = i * 1.7
        px = S(450) + math.cos(a) * (S(340) + (i % 3) * S(20))
        py = S(445) + math.sin(a) * (S(300) + (i % 4) * S(14))
        d.ellipse((px - S(3), py - S(3), px + S(3), py + S(3)), fill=(255, 255, 255, 90))
    out = downsample(img, size)
    bbox = out.getbbox()
    if bbox:
        pad = 18
        bbox = (max(0, bbox[0] - pad), max(0, bbox[1] - pad),
                min(out.width, bbox[2] + pad), min(out.height, bbox[3] + pad))
        out = out.crop(bbox)
    return out


def make_pat():
    size = 512
    scale = 2
    img = canvas(size, scale)
    d = ImageDraw.Draw(img)
    fill_round_gradient(img, (S(30), S(30), S(482), S(482)), S(80), (255, 247, 232, 255), (255, 228, 226, 255), NAVY, S(7))
    # halo ring
    d.ellipse((S(110), S(86), S(402), S(310)), outline=(255, 214, 118, 255), width=S(18))
    # hand silhouette (palm + four fingers + thumb)
    hand = [
        (S(198), S(414)), (S(174), S(330)), (S(181), S(278)),
        (S(202), S(272)), (S(215), S(300)), (S(220), S(346)),
        (S(216), S(244)), (S(239), S(240)), (S(252), S(302)),
        (S(258), S(220)), (S(282), S(218)), (S(291), S(300)),
        (S(304), S(236)), (S(326), S(239)), (S(329), S(310)),
        (S(359), S(270)), (S(378), S(282)), (S(365), S(342)),
        (S(345), S(402)), (S(314), S(432)), (S(250), S(438)),
    ]
    d.polygon(hand, fill=(255, 253, 245, 255), outline=NAVY)
    d.line(hand + [hand[0]], fill=NAVY, width=S(7), joint="curve")
    # small heart above the palm
    hx, hy, hr = S(263), S(334), S(38)
    d.polygon([
        (hx, hy + hr), (hx - hr, hy - hr * 0.08), (hx - hr * 0.58, hy - hr * 0.62),
        (hx, hy - hr * 0.16), (hx + hr * 0.58, hy - hr * 0.62), (hx + hr, hy - hr * 0.08),
    ], fill=PINK, outline=NAVY)
    # motion sparkles
    for sx, sy, sr in [(S(128), S(180), S(18)), (S(384), S(194), S(15)), (S(405), S(392), S(20))]:
        sparkle(d, sx, sy, sr, GOLD, NAVY, S(4))
    return downsample(img, size)


def make_course():
    size = 512
    scale = 2
    img = canvas(size, scale)
    d = ImageDraw.Draw(img)
    fill_round_gradient(img, (S(30), S(30), S(482), S(482)), S(80), (249, 255, 245, 255), (218, 244, 229, 255), NAVY, S(7))
    # notebook
    shadow(img, (S(116), S(108), S(396), S(428)), S(36), offset=(0, S(9)), blur=S(9), alpha=60)
    d.rounded_rectangle((S(116), S(96), S(396), S(416)), radius=S(32), fill=(255, 253, 242, 255), outline=NAVY, width=S(8))
    # spiral binding
    for y in range(S(132), S(396), S(44)):
        d.rounded_rectangle((S(104), y, S(142), y + S(18)), radius=S(9), fill=(243, 201, 102, 255), outline=NAVY, width=S(4))
    # ruled lines / timetable
    for i, y in enumerate(range(S(158), S(360), S(44))):
        d.line((S(166), y, S(354), y), fill=(144, 190, 205, 160), width=S(4))
    d.line((S(166), S(144), S(166), S(372)), fill=(144, 190, 205, 160), width=S(4))
    # check marks
    for i, y in enumerate(range(S(158), S(330), S(44))):
        if i % 2 == 0:
            d.line((S(286), y + S(10), S(306), y + S(26), S(338), y - S(8)), fill=MINT_DARK, width=S(9), joint="curve")
    # pencil
    d.line((S(306), S(432), S(410), S(328)), fill=NAVY, width=S(30))
    d.line((S(306), S(432), S(410), S(328)), fill=GOLD, width=S(22))
    d.polygon([(S(298), S(446)), (S(306), S(412)), (S(328), S(432))], fill=(255, 238, 198, 255), outline=NAVY)
    d.polygon([(S(298), S(446)), (S(305), S(423)), (S(317), S(435))], fill=NAVY)
    # star sticker
    sparkle(d, S(120), S(120), S(28), PINK, NAVY, S(4))
    return downsample(img, size)


def make_sidebar_bg():
    w, h = 500, 1100
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    # fine grid and orbit lines, very subtle
    for x in range(0, w, 34):
        d.line((x, 0, x, h), fill=(101, 174, 220, 18), width=1)
    for y in range(0, h, 34):
        d.line((0, y, w, y), fill=(101, 174, 220, 18), width=1)
    d.arc((60, 660, 620, 1230), 190, 330, fill=(247, 197, 86, 60), width=3)
    d.arc((110, 700, 570, 1180), 190, 330, fill=(101, 174, 220, 45), width=2)
    for i in range(26):
        a = i * 0.9
        x = int(250 + math.cos(a) * (130 + (i % 4) * 22))
        y = int(1020 + math.sin(a) * (95 + (i % 3) * 18))
        d.ellipse((x - 2, y - 2, x + 2, y + 2), fill=(255, 255, 255, 40))
    return img


def main():
    app = make_app_icon()
    app.save(OUT / "app.png")
    # multi-size Windows icon
    sizes = [(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (24, 24), (20, 20), (16, 16)]
    app.save(OUT / "app.ico", sizes=sizes)

    make_hero().save(OUT / "hero_gifts.png")
    make_pat().save(OUT / "item_pat.png")
    make_course().save(OUT / "item_course.png")
    specs = [
        ("item_20", BLUE_LIGHT, BLUE, GOLD, "none", (125, 200, 235, 110)),
        ("item_40", BLUE_LIGHT, BLUE, GOLD, "smile", (125, 200, 235, 110)),
        ("item_60", (143, 217, 245, 255), (47, 132, 205, 255), GOLD, "big", (125, 200, 235, 110)),
        ("item_120", PURPLE_LIGHT, PURPLE, GOLD_LIGHT, "none", (208, 188, 245, 110)),
        ("item_180", PURPLE_LIGHT, PURPLE, GOLD_LIGHT, "big", (208, 188, 245, 110)),
        ("item_240", (207, 180, 248, 255), (122, 87, 185, 255), (255, 214, 126, 255), "heart", (208, 188, 245, 110)),
    ]
    for name, a, b, rib, face, accent in specs:
        face_icon(name, a, b, rib, face, accent).save(OUT / f"{name}.png")
    make_sidebar_bg().save(OUT / "sidebar_bg.png")

    print("generated:", ", ".join(sorted(p.name for p in OUT.iterdir())))


if __name__ == "__main__":
    main()
