﻿# 蔚蓝档案 · 好感计算器 v2.0（源码）

本目录是发布包中 EXE 对应的源码与素材。程序使用 **C++17 + Win32 + GDI+** 编写，
不依赖 Qt、Electron、.NET 或任何第三方 UI 库。

## 文件

```text
main.cpp         主程序：窗口、绘制、输入、计算、资源加载
app.rc           Windows 资源脚本：图标、PNG、版本信息、Manifest
app.manifest     高 DPI / 长路径 / 兼容性声明
assets/          原创图标与插画
  tools/make_assets.py  素材生成脚本（Pillow）
原版_控制台版.c  原工具的 C 语言控制台实现，保留作对照
```

## 构建环境

- Visual Studio 2022 或 2026，安装“使用 C++ 的桌面开发”
- Windows 10/11 SDK（10.0.26100 或相近版本）
- 建议在 “x64 Native Tools Command Prompt for VS” 中构建

## 构建命令

在源码根目录（`app.rc` 所在目录）执行：

```bat
rc /nologo /c65001 /fo build\app.res app.rc

cl /nologo /utf-8 /std:c++17 /EHsc /O2 /MT ^
   /DUNICODE /D_UNICODE /D_WIN32_WINNT=0x0A00 /DWINVER=0x0A00 ^
   main.cpp build\app.res ^
   /Fe:好感计算器.exe ^
   /link /MANIFEST:NO /SUBSYSTEM:WINDOWS ^
   user32.lib gdi32.lib gdiplus.lib ole32.lib shell32.lib ^
   comctl32.lib uxtheme.lib dwmapi.lib
```

`/MT` 会把 C/C++ 运行库静态链接进 EXE，因此发布时不需要 VC++ Redistributable。
`/MANIFEST:NO` 是因为 Manifest 已经通过 `app.rc` 嵌入，避免重复。

## 素材

`assets/` 中的 PNG/ICO 是程序运行时通过 Windows 资源段读取的，
不是外部文件；发布时只需要 EXE。素材生成脚本位于本工作区的
`tools/make_assets.py`，使用 Pillow 绘制，可复现。

## 说明

- 原版逻辑中的等级表、礼物效率、摸头/课程表/活动/制造公式被保留。
- 修正了原版把“当前等级经验”加到总需求上的问题，改为从总需求扣除。
- 计算页和规划页的核心函数集中在 `main.cpp` 的 `Recalculate()` 与
  `CalculatePlan()`，便于核对。
- 本工具是非官方粉丝工具；游戏数值可能随版本调整。
