// -----------------------------------------------------------------------------
//  Blue Archive - Affection & Gift Planner
//  A native Win32/GDI+ desktop remake of the original console calculator.
//
//  The application is intentionally self-contained: all artwork and fonts
//  references are embedded, calculations happen locally, and the C runtime is
//  linked statically.
// -----------------------------------------------------------------------------
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <dwmapi.h>
#include <objidl.h>
#include <ole2.h>
#include <gdiplus.h>
#include <shellapi.h>
#include <uxtheme.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cwchar>
#include <string>
#include <vector>

using namespace Gdiplus;

// -----------------------------------------------------------------------------
//  Resource ids
// -----------------------------------------------------------------------------
#define IDI_APP                 101
#define IDR_APP_PNG             201
#define IDR_HERO_PNG            202
#define IDR_ITEM_PAT            203
#define IDR_ITEM_20             204
#define IDR_ITEM_40             205
#define IDR_ITEM_60             206
#define IDR_ITEM_120            207
#define IDR_ITEM_180            208
#define IDR_ITEM_240            209
#define IDR_ITEM_COURSE         210
#define IDR_SIDEBAR             211

#define ID_EDIT_CUR             1001
#define ID_EDIT_EXP             1002
#define ID_EDIT_TARGET          1003
#define ID_EDIT_PATS            1004
#define ID_EDIT_M1              1005
#define ID_EDIT_M2              1006
#define ID_EDIT_N1              1007
#define ID_EDIT_N2              1008
#define ID_EDIT_BASE            1001
#define ID_EDIT_LAST            1008

// -----------------------------------------------------------------------------
//  Palette
// -----------------------------------------------------------------------------
static const Color C_BG_TOP      (255, 252, 248, 239);
static const Color C_BG_BOTTOM   (255, 241, 237, 228);
static const Color C_SIDEBAR     (255, 250, 245, 235);
static const Color C_CARD        (255, 255, 253, 248);
static const Color C_CARD_BLUE   (255, 247, 251, 255);
static const Color C_INK         (255, 40, 54, 79);
static const Color C_INK_SOFT    (255, 72, 86, 110);
static const Color C_MUTED       (255, 125, 137, 154);
static const Color C_FAINT       (255, 170, 178, 188);
static const Color C_LINE        (255, 226, 228, 229);
static const Color C_LINE_BLUE   (255, 219, 232, 245);
static const Color C_FIELD       (255, 246, 249, 253);
static const Color C_FIELD_FOCUS (255, 238, 248, 255);
static const Color C_BLUE        (255, 53, 139, 211);
static const Color C_BLUE_DARK   (255, 36, 103, 174);
static const Color C_BLUE_LIGHT  (255, 139, 208, 247);
static const Color C_NAVY        (255, 30, 62, 104);
static const Color C_PINK        (255, 239, 132, 164);
static const Color C_PINK_DARK   (255, 203, 83, 126);
static const Color C_GOLD        (255, 247, 196, 85);
static const Color C_GOLD_LIGHT  (255, 255, 227, 146);
static const Color C_GOLD_DARK   (255, 213, 151, 44);
static const Color C_MINT        (255, 96, 196, 174);
static const Color C_PURPLE      (255, 155, 127, 219);
static const Color C_WHITE       (255, 255, 255, 255);
static const Color C_WHITE_SOFT  (235, 255, 255, 255);
static const Color C_SHADOW      (30, 31, 44, 67);

// -----------------------------------------------------------------------------
//  App constants
// -----------------------------------------------------------------------------
static const int BASE_W = 1180;
static const int BASE_H = 800;
static const int TITLE_H = 42;
static const int SIDEBAR_W = 232;

static const int PAGE_CALC = 0;
static const int PAGE_PLAN = 1;
static const int PAGE_HELP = 2;

static const UINT WM_APP_PRIMARY = WM_APP + 1;
static const UINT_PTR TIMER_ANIM = 1;
static const UINT_PTR TIMER_TOAST = 2;

// -----------------------------------------------------------------------------
//  Level table (EXP needed to advance from level i to i+1)
// -----------------------------------------------------------------------------
static const int LEVEL_EXP[100] = {
    0, 15, 30, 30, 35, 35, 35, 40, 40, 40,
    60, 90, 105, 120, 140, 160, 180, 205, 230, 255,
    285, 315, 345, 375, 410, 445, 480, 520, 560, 600,
    645, 690, 735, 780, 830, 880, 930, 985, 1040, 1095,
    1155, 1215, 1275, 1335, 1400, 1465, 1530, 1600, 1670, 1740,
    1815, 1890, 1965, 2040, 2120, 2200, 2280, 2365, 2450, 2535,
    2625, 2715, 2805, 2895, 2990, 3085, 3180, 3280, 3380, 3480,
    3585, 3690, 3795, 3900, 4010, 4120, 4230, 4345, 4460, 4575,
    4695, 4815, 4935, 5055, 5180, 5305, 5430, 5560, 5690, 5820,
    5955, 6090, 6225, 6360, 6500, 6640, 6780, 6925, 7070, 7215
};

struct ItemDef {
    int         resource;
    const wchar_t* name;
    double      exp;
    const wchar_t* unit;
    int         kind; // 0 pat, 1 normal, 2 purple, 3 course
};

static const ItemDef ITEMS[8] = {
    { IDR_ITEM_PAT,    L"摸头",       15.0, L"次", 0 },
    { IDR_ITEM_20,     L"普通礼物",   20.0, L"个", 1 },
    { IDR_ITEM_40,     L"微笑礼物",   40.0, L"个", 1 },
    { IDR_ITEM_60,     L"大笑脸礼物", 60.0, L"个", 1 },
    { IDR_ITEM_120,    L"紫色礼物",  120.0, L"个", 2 },
    { IDR_ITEM_180,    L"紫色大笑脸",180.0, L"个", 2 },
    { IDR_ITEM_240,    L"紫色爱心脸",240.0, L"个", 2 },
    { IDR_ITEM_COURSE, L"课程表",     32.5, L"次", 3 },
};

// -----------------------------------------------------------------------------
//  Globals
// -----------------------------------------------------------------------------
static HINSTANCE   g_hinst = nullptr;
static HWND        g_hwnd = nullptr;
static ULONG_PTR   g_gdiplusToken = 0;
static float       g_scale = 1.0f;
static int         g_winW = BASE_W;
static int         g_winH = BASE_H;
static int         g_dpi = 96;
static int         g_page = PAGE_CALC;
static int         g_hover = 0;
static bool        g_trackingMouse = false;

static HFONT       g_editFontBig = nullptr;
static HFONT       g_editFontMed = nullptr;
static HFONT       g_editFontSmall = nullptr;
static HBRUSH      g_fieldBrush = nullptr;
static HBRUSH      g_fieldFocusBrush = nullptr;
static HBRUSH      g_disabledBrush = nullptr;

static Font*       g_fH1 = nullptr;
static Font*       g_fH2 = nullptr;
static Font*       g_fH3 = nullptr;
static Font*       g_fBody = nullptr;
static Font*       g_fBodyBold = nullptr;
static Font*       g_fSmall = nullptr;
static Font*       g_fSmallBold = nullptr;
static Font*       g_fTiny = nullptr;
static Font*       g_fTinyBold = nullptr;
static Font*       g_fNum = nullptr;
static Font*       g_fNumBig = nullptr;
static Font*       g_fNumHuge = nullptr;
static Font*       g_fButton = nullptr;
static Font*       g_fBrand = nullptr;

static Bitmap*     g_imgApp = nullptr;
static Bitmap*     g_imgHero = nullptr;
static Bitmap*     g_imgSidebar = nullptr;
static Bitmap*     g_imgItems[8] = {};

// -----------------------------------------------------------------------------
//  Layout rectangles (design-space units)
// -----------------------------------------------------------------------------
struct UIRect {
    float x = 0, y = 0, w = 0, h = 0;
    bool Contains(float px, float py) const {
        return px >= x && py >= y && px <= x + w && py <= y + h;
    }
    RectF R() const { return RectF(x, y, w, h); }
};

static UIRect g_rInputCard, g_rResultCard, g_rGiftCard;
static UIRect g_rPlanSettings, g_rPlanHero, g_rPlanBreak;
static UIRect g_rHelpLeft, g_rHelpRight;
static UIRect g_rField[8];
static UIRect g_rPreset[3];
static UIRect g_rCraft[3];
static UIRect g_rCalcButton, g_rPlanButton, g_rBackButton;
static UIRect g_rCopyButton, g_rPlanLinkButton, g_rResetButton;
static UIRect g_rNav[3];
static UIRect g_rMin, g_rClose, g_rToggle;
static UIRect g_rHelpAction;

// -----------------------------------------------------------------------------
//  Calculation results
// -----------------------------------------------------------------------------
struct CalcResult {
    bool       valid = false;
    int        cur = 1;
    int        target = 100;
    int        curExp = 0;
    long long  remaining = 0;
    long long  totalTarget = 0;
    long long  totalCurrent = 0;
    int        span = 0;
    long long  count[8] = {};
    std::wstring error;
};

static CalcResult g_calc;
static bool       g_calcDirty = true;

struct PlanResult {
    bool       valid = false;
    bool       implemented = true;
    int        pats = 3;
    int        craft = 3;
    int        m1 = 5;
    int        m2 = 2;
    int        n1 = 1;
    int        n2 = 1;
    double     mValue = 0;
    double     nValue = 0;
    double     activity = 0;
    double     craftExp = 0;
    double     patsExp = 0;
    double     courseExp = 0;
    double     total = 0;
    double     extra = 0;
    double     altTotal = 0;
    int        days = 0;
    int        altDays = 0;
    long long  remaining = 0;
    SYSTEMTIME date = {};
    std::wstring error;
};

static PlanResult g_plan;
static bool       g_implemented = true;
static int        g_craft = 3;
static int        g_pats = 3;
static int        g_m1 = 5;
static int        g_m2 = 2;
static int        g_n1 = 1;
static int        g_n2 = 1;

// animation / toast
static bool       g_animating = false;
static ULONGLONG  g_animStart = 0;
static double     g_displayRemaining = 0;
static double     g_animFrom = 0;
static double     g_animTo = 0;
static std::wstring g_toast;
static ULONGLONG  g_toastUntil = 0;

// DWM
typedef HRESULT (WINAPI* DwmSetWindowAttributeFn)(HWND, DWORD, LPCVOID, DWORD);
static DwmSetWindowAttributeFn g_dwmSetWindowAttribute = nullptr;

// =============================================================================
//  Small utilities
// =============================================================================
static inline float P(float v) { return v * g_scale; }
static inline int   PI(float v) { return (int)std::lround(v * g_scale); }
static inline float Clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static inline int   Clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
static inline double Clampd(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }

static std::wstring Num(long long value) {
    wchar_t raw[40];
    swprintf_s(raw, L"%lld", value);
    std::wstring s(raw);
    bool neg = false;
    if (!s.empty() && s[0] == L'-') { neg = true; s.erase(s.begin()); }
    std::wstring out;
    int n = (int)s.size();
    for (int i = 0; i < n; ++i) {
        if (i > 0 && (n - i) % 3 == 0) out.push_back(L',');
        out.push_back(s[i]);
    }
    if (neg) out.insert(out.begin(), L'-');
    return out;
}

static std::wstring Num1(double value) {
    wchar_t buf[64];
    swprintf_s(buf, L"%.1f", value);
    return buf;
}

static std::wstring IntText(int value) { return Num(value); }

static long long NeedTo(int from, int to) {
    if (to <= from) return 0;
    from = Clampi(from, 0, 99);
    to = Clampi(to, 0, 100);
    long long sum = 0;
    for (int i = from; i < to; ++i) sum += LEVEL_EXP[i];
    return sum;
}

static long long TotalTo(int level) {
    level = Clampi(level, 0, 100);
    long long sum = 0;
    for (int i = 0; i < level; ++i) sum += LEVEL_EXP[i];
    return sum;
}

static std::wstring GetEditText(HWND hwnd, int id) {
    wchar_t buf[64] = {};
    GetDlgItemTextW(hwnd, id, buf, 63);
    return buf;
}

static int ReadInt(HWND hwnd, int id, int fallback) {
    std::wstring s = GetEditText(hwnd, id);
    if (s.empty()) return fallback;
    wchar_t* end = nullptr;
    long long v = wcstoll(s.c_str(), &end, 10);
    if (end == s.c_str()) return fallback;
    return (int)Clampd((double)v, -2000000000.0, 2000000000.0);
}

static void SetEditInt(HWND hwnd, int id, int value) {
    wchar_t buf[64];
    swprintf_s(buf, L"%d", value);
    SetDlgItemTextW(hwnd, id, buf);
}

static void AddToast(const std::wstring& text) {
    g_toast = text;
    g_toastUntil = GetTickCount64() + 2100;
    SetTimer(g_hwnd, TIMER_TOAST, 2100, nullptr);
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

// =============================================================================
//  GDI+ drawing helpers
// =============================================================================
static void AddRoundRect(GraphicsPath& path, RectF r, float radius) {
    float d = radius * 2.0f;
    if (d > r.Width) d = r.Width;
    if (d > r.Height) d = r.Height;
    if (d <= 0.1f) {
        path.AddRectangle(r);
        return;
    }
    path.AddArc(r.X, r.Y, d, d, 180.0f, 90.0f);
    path.AddArc(r.X + r.Width - d, r.Y, d, d, 270.0f, 90.0f);
    path.AddArc(r.X + r.Width - d, r.Y + r.Height - d, d, d, 0.0f, 90.0f);
    path.AddArc(r.X, r.Y + r.Height - d, d, d, 90.0f, 90.0f);
    path.CloseFigure();
}

static void FillRound(Graphics& g, RectF r, float radius, const Color& c) {
    GraphicsPath p;
    AddRoundRect(p, r, radius);
    SolidBrush b(c);
    g.FillPath(&b, &p);
}

static void StrokeRound(Graphics& g, RectF r, float radius, const Color& c, float width = 1.0f) {
    GraphicsPath p;
    AddRoundRect(p, r, radius);
    Pen pen(c, width);
    g.DrawPath(&pen, &p);
}

static void Shadow(Graphics& g, RectF r, float radius, float dy = 3.0f, float alpha = 24.0f) {
    for (int i = 3; i >= 1; --i) {
        float off = dy + i * 1.4f;
        float grow = i * 0.9f;
        RectF rr(r.X - grow, r.Y + off, r.Width + grow * 2, r.Height + grow);
        FillRound(g, rr, radius + grow, Color((BYTE)(alpha / (i * 1.8f)), 31, 44, 67));
    }
}

static void Panel(Graphics& g, RectF r, float radius, const Color& fill,
                  const Color& border = C_LINE, bool shadow = true) {
    if (shadow) Shadow(g, r, radius);
    FillRound(g, r, radius, fill);
    StrokeRound(g, r, radius, border, 1.0f);
}

static void GradientRect(Graphics& g, RectF r, float radius, const Color& a, const Color& b,
                         LinearGradientMode mode = LinearGradientModeVertical) {
    GraphicsPath p;
    AddRoundRect(p, r, radius);
    LinearGradientBrush brush(r, a, b, mode);
    g.FillPath(&brush, &p);
}

static void Text(Graphics& g, const std::wstring& s, RectF r, Font* font, const Color& color,
                 StringAlignment hAlign = StringAlignmentNear,
                 StringAlignment vAlign = StringAlignmentNear,
                 bool wrap = false, bool ellipsis = false) {
    if (!font || s.empty()) return;
    StringFormat fmt;
    fmt.SetAlignment(hAlign);
    fmt.SetLineAlignment(vAlign);
    fmt.SetFormatFlags(wrap ? 0 : StringFormatFlagsNoWrap);
    if (ellipsis) fmt.SetTrimming(StringTrimmingEllipsisCharacter);
    SolidBrush brush(color);
    g.DrawString(s.c_str(), -1, font, r, &fmt, &brush);
}

static void Text(Graphics& g, const wchar_t* s, RectF r, Font* font, const Color& color,
                 StringAlignment hAlign = StringAlignmentNear,
                 StringAlignment vAlign = StringAlignmentNear,
                 bool wrap = false, bool ellipsis = false) {
    Text(g, std::wstring(s ? s : L""), r, font, color, hAlign, vAlign, wrap, ellipsis);
}

static void TextCenter(Graphics& g, const std::wstring& s, RectF r, Font* font, const Color& color,
                       bool wrap = false) {
    Text(g, s, r, font, color, StringAlignmentCenter, StringAlignmentCenter, wrap);
}

static float Measure(Graphics& g, const std::wstring& s, Font* font) {
    if (!font || s.empty()) return 0;
    RectF layout(0, 0, 2000, 200);
    RectF bounds;
    StringFormat fmt;
    fmt.SetFormatFlags(StringFormatFlagsNoWrap);
    g.MeasureString(s.c_str(), -1, font, layout, &fmt, &bounds);
    return bounds.Width;
}

static void Star(Graphics& g, float cx, float cy, float r, const Color& fill,
                 const Color& outline = Color(0, 0, 0, 0), float outlineWidth = 0.0f) {
    PointF pts[8] = {
        PointF(cx, cy - r),
        PointF(cx + r * 0.23f, cy - r * 0.23f),
        PointF(cx + r, cy),
        PointF(cx + r * 0.23f, cy + r * 0.23f),
        PointF(cx, cy + r),
        PointF(cx - r * 0.23f, cy + r * 0.23f),
        PointF(cx - r, cy),
        PointF(cx - r * 0.23f, cy - r * 0.23f),
    };
    SolidBrush b(fill);
    g.FillPolygon(&b, pts, 8);
    if (outline.GetA() > 0 && outlineWidth > 0) {
        Pen p(outline, outlineWidth);
        g.DrawPolygon(&p, pts, 8);
    }
}

static void Dot(Graphics& g, float cx, float cy, float r, const Color& c) {
    SolidBrush b(c);
    g.FillEllipse(&b, cx - r, cy - r, r * 2, r * 2);
}

static void Line(Graphics& g, float x1, float y1, float x2, float y2, const Color& c, float width = 1.0f) {
    Pen p(c, width);
    g.DrawLine(&p, x1, y1, x2, y2);
}

static void Halo(Graphics& g, float cx, float cy, float rx, float ry, const Color& c, float width) {
    Pen p(c, width);
    g.DrawEllipse(&p, cx - rx, cy - ry, rx * 2, ry * 2);
}

static void DrawImageFit(Graphics& g, Bitmap* bmp, RectF box, bool fit = true) {
    if (!bmp) return;
    float iw = (float)bmp->GetWidth();
    float ih = (float)bmp->GetHeight();
    if (iw <= 0 || ih <= 0) return;
    float scale = fit ? std::min(box.Width / iw, box.Height / ih)
                      : std::max(box.Width / iw, box.Height / ih);
    float w = iw * scale, h = ih * scale;
    float x = box.X + (box.Width - w) * 0.5f;
    float y = box.Y + (box.Height - h) * 0.5f;
    g.SetInterpolationMode(InterpolationModeHighQualityBicubic);
    g.SetPixelOffsetMode(PixelOffsetModeHighQuality);
    g.DrawImage(bmp, RectF(x, y, w, h));
}

static void DrawImageAlpha(Graphics& g, Bitmap* bmp, RectF box, BYTE alpha) {
    if (!bmp) return;
    ImageAttributes attr;
    ColorMatrix cm = {
        1,0,0,0,0,
        0,1,0,0,0,
        0,0,1,0,0,
        0,0,0,alpha / 255.0f,0,
        0,0,0,0,1
    };
    attr.SetColorMatrix(&cm);
    g.DrawImage(bmp, RectF(box.X, box.Y, box.Width, box.Height),
                0, 0, (float)bmp->GetWidth(), (float)bmp->GetHeight(),
                UnitPixel, &attr);
}

// =============================================================================
//  Embedded resources / fonts
// =============================================================================
static Bitmap* LoadPngResource(int id) {
    HRSRC hr = FindResourceW(g_hinst, MAKEINTRESOURCEW(id), RT_RCDATA);
    if (!hr) return nullptr;
    DWORD size = SizeofResource(g_hinst, hr);
    HGLOBAL hg = LoadResource(g_hinst, hr);
    if (!hg || size == 0) return nullptr;
    void* data = LockResource(hg);
    if (!data) return nullptr;
    IStream* stream = nullptr;
    if (FAILED(CreateStreamOnHGlobal(nullptr, TRUE, &stream)) || !stream) return nullptr;
    ULONG written = 0;
    stream->Write(data, size, &written);
    LARGE_INTEGER zero = {};
    stream->Seek(zero, STREAM_SEEK_SET, nullptr);
    Bitmap* bmp = Bitmap::FromStream(stream, FALSE);
    stream->Release();
    return bmp;
}

static void CreateFonts() {
    delete g_fH1; delete g_fH2; delete g_fH3; delete g_fBody; delete g_fBodyBold;
    delete g_fSmall; delete g_fSmallBold; delete g_fTiny; delete g_fTinyBold;
    delete g_fNum; delete g_fNumBig; delete g_fNumHuge; delete g_fButton; delete g_fBrand;

    g_fH1       = new Font(L"Microsoft YaHei UI", 28.0f, FontStyleBold, UnitPixel);
    g_fH2       = new Font(L"Microsoft YaHei UI", 19.0f, FontStyleBold, UnitPixel);
    g_fH3       = new Font(L"Microsoft YaHei UI", 14.0f, FontStyleBold, UnitPixel);
    g_fBody     = new Font(L"Microsoft YaHei UI", 11.5f, FontStyleRegular, UnitPixel);
    g_fBodyBold = new Font(L"Microsoft YaHei UI", 11.5f, FontStyleBold, UnitPixel);
    g_fSmall    = new Font(L"Microsoft YaHei UI", 9.5f, FontStyleRegular, UnitPixel);
    g_fSmallBold= new Font(L"Microsoft YaHei UI", 9.5f, FontStyleBold, UnitPixel);
    g_fTiny     = new Font(L"Microsoft YaHei UI", 8.0f, FontStyleRegular, UnitPixel);
    g_fTinyBold = new Font(L"Microsoft YaHei UI", 8.0f, FontStyleBold, UnitPixel);
    g_fNum      = new Font(L"Bahnschrift", 18.0f, FontStyleBold, UnitPixel);
    g_fNumBig   = new Font(L"Bahnschrift", 23.0f, FontStyleBold, UnitPixel);
    g_fNumHuge  = new Font(L"Bahnschrift", 48.0f, FontStyleBold, UnitPixel);
    g_fButton   = new Font(L"Microsoft YaHei UI", 13.0f, FontStyleBold, UnitPixel);
    g_fBrand    = new Font(L"Microsoft YaHei UI", 18.0f, FontStyleBold, UnitPixel);
}

static void CreateEditFonts() {
    if (g_editFontBig) DeleteObject(g_editFontBig);
    if (g_editFontMed) DeleteObject(g_editFontMed);
    if (g_editFontSmall) DeleteObject(g_editFontSmall);
    g_editFontBig = CreateFontW(-PI(28), 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                                DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Microsoft YaHei UI");
    g_editFontMed = CreateFontW(-PI(19), 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
                                DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Microsoft YaHei UI");
    g_editFontSmall = CreateFontW(-PI(16), 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
                                  DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                  CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Microsoft YaHei UI");
}

static void CreateBrushes() {
    if (g_fieldBrush) DeleteObject(g_fieldBrush);
    if (g_fieldFocusBrush) DeleteObject(g_fieldFocusBrush);
    if (g_disabledBrush) DeleteObject(g_disabledBrush);
    g_fieldBrush = CreateSolidBrush(RGB(246, 249, 253));
    g_fieldFocusBrush = CreateSolidBrush(RGB(238, 248, 255));
    g_disabledBrush = CreateSolidBrush(RGB(243, 244, 246));
}

// =============================================================================
//  Calculations
// =============================================================================
static long long CeilDiv(long long a, long long b) {
    if (b <= 0) return 0;
    return (a + b - 1) / b;
}

static void Recalculate() {
    g_calc.valid = false;
    g_calc.error.clear();

    int cur = ReadInt(g_hwnd, ID_EDIT_CUR, 1);
    int exp = ReadInt(g_hwnd, ID_EDIT_EXP, 0);
    int target = ReadInt(g_hwnd, ID_EDIT_TARGET, 100);

    if (cur < 1 || cur > 100) {
        g_calc.error = L"当前等级需要在 1 到 100 之间。";
        return;
    }
    if (target < 1 || target > 100) {
        g_calc.error = L"目标等级需要在 1 到 100 之间。";
        return;
    }
    if (target <= cur) {
        g_calc.error = L"目标等级需要高于当前等级。";
        return;
    }
    if (cur == 100) {
        g_calc.error = L"已达到最高好感等级，不需要继续升级。";
        return;
    }

    int maxExp = LEVEL_EXP[cur] - 1;
    if (exp < 0) exp = 0;
    if (exp > maxExp) {
        exp = maxExp;
        SetEditInt(g_hwnd, ID_EDIT_EXP, exp);
        AddToast(L"当前经验已按本等级上限处理");
    }

    long long need = NeedTo(cur, target);
    long long remaining = need - exp;
    if (remaining <= 0) {
        g_calc.error = L"当前经验已经满足目标，请提高目标等级。";
        return;
    }

    g_calc.cur = cur;
    g_calc.target = target;
    g_calc.curExp = exp;
    g_calc.remaining = remaining;
    g_calc.totalTarget = TotalTo(target);
    g_calc.totalCurrent = TotalTo(cur) + exp;
    g_calc.span = target - cur;

    for (int i = 0; i < 8; ++i) {
        if (i == 7) {
            // course table: 32.5 EXP per attempt, ceil(remaining / 32.5)
            g_calc.count[i] = CeilDiv(remaining * 2, 65);
        } else {
            long long per = (long long)ITEMS[i].exp;
            g_calc.count[i] = CeilDiv(remaining, per);
        }
    }

    g_calc.valid = true;
    g_calcDirty = true;

    g_animFrom = g_displayRemaining;
    g_animTo = (double)remaining;
    g_animStart = GetTickCount64();
    g_animating = true;
    SetTimer(g_hwnd, TIMER_ANIM, 15, nullptr);
}

static SYSTEMTIME AddDaysToToday(int days) {
    SYSTEMTIME now;
    GetLocalTime(&now);
    FILETIME ft;
    SystemTimeToFileTime(&now, &ft);
    ULARGE_INTEGER u;
    u.LowPart = ft.dwLowDateTime;
    u.HighPart = ft.dwHighDateTime;
    u.QuadPart += (ULONGLONG)days * 864000000000ULL;
    ft.dwLowDateTime = u.LowPart;
    ft.dwHighDateTime = u.HighPart;
    SYSTEMTIME out;
    FileTimeToSystemTime(&ft, &out);
    return out;
}

static void CalculatePlan(bool showErrorToast) {
    g_plan.error.clear();
    if (!g_calc.valid) {
        g_plan.valid = false;
        g_plan.error = L"请先完成左侧的礼物计算。";
        return;
    }

    int pats = ReadInt(g_hwnd, ID_EDIT_PATS, 3);
    int m1 = ReadInt(g_hwnd, ID_EDIT_M1, 5);
    int m2 = ReadInt(g_hwnd, ID_EDIT_M2, 2);
    int n1 = ReadInt(g_hwnd, ID_EDIT_N1, 1);
    int n2 = ReadInt(g_hwnd, ID_EDIT_N2, 1);

    pats = Clampi(pats, 0, 99);
    m1 = Clampi(m1, 0, 35);
    m2 = Clampi(m2, 0, 35);
    n1 = Clampi(n1, 0, 13);
    n2 = Clampi(n2, 0, 13);

    if (m1 + m2 > 35) {
        g_plan.valid = false;
        g_plan.error = L"普通礼物数量之和不能超过 35。";
        if (showErrorToast) AddToast(g_plan.error);
        return;
    }
    if (n1 + n2 > 13) {
        g_plan.valid = false;
        g_plan.error = L"紫色礼物数量之和不能超过 13。";
        if (showErrorToast) AddToast(g_plan.error);
        return;
    }
    if (!g_implemented) pats = 0;

    double m = (m1 * 40.0 + m2 * 60.0 + (35 - m1 - m2) * 20.0) / 35.0;
    double n = (n2 * 240.0 + n1 * 180.0 + (13 - n1 - n2) * 120.0) / 13.0;

    double activity = 12.0 * 2.0 * (3.0 * n + 80.0 * m) / 356.25;
    double craftExp = g_craft * (2.45 * m + 0.32 * n);
    double patsExp = pats * 15.0;
    double courseExp = g_implemented ? (32.5 * 175.0 / 230.0) : 0.0;
    double extra = (10.0 * 2.0 * 12.0 * 80.0 * (35 - m1 - m2)) / (35.0 * 356.25)
                 + (10.0 * g_craft * 2.45 * (35 - m1 - m2)) / 35.0;

    double total = activity + craftExp + patsExp + courseExp;
    if (total <= 0.0001) {
        g_plan.valid = false;
        g_plan.error = L"每日经验为 0，请至少保留一种获取来源。";
        if (showErrorToast) AddToast(g_plan.error);
        return;
    }

    g_plan.valid = true;
    g_plan.implemented = g_implemented;
    g_plan.pats = pats;
    g_plan.craft = g_craft;
    g_plan.m1 = m1; g_plan.m2 = m2; g_plan.n1 = n1; g_plan.n2 = n2;
    g_plan.mValue = m;
    g_plan.nValue = n;
    g_plan.activity = activity;
    g_plan.craftExp = craftExp;
    g_plan.patsExp = patsExp;
    g_plan.courseExp = courseExp;
    g_plan.total = total;
    g_plan.extra = extra;
    g_plan.altTotal = total + extra;
    g_plan.remaining = g_calc.remaining;
    g_plan.days = (int)std::ceil((double)g_calc.remaining / total);
    g_plan.altDays = (int)std::ceil((double)g_calc.remaining / g_plan.altTotal);
    g_plan.date = AddDaysToToday(g_plan.days);
    g_calcDirty = false;
}

static std::wstring BuildSummary() {
    std::wstring out = L"蔚蓝档案 · 好感计算器\n";
    if (g_calc.valid) {
        wchar_t line[256];
        swprintf_s(line, L"Lv.%d（%d EXP） → Lv.%d\n", g_calc.cur, g_calc.curExp, g_calc.target);
        out += line;
        out += L"还需好感经验：" + Num(g_calc.remaining) + L" EXP\n";
        for (int i = 0; i < 8; ++i) {
            out += ITEMS[i].name;
            out += L"：" + Num(g_calc.count[i]) + ITEMS[i].unit + L"\n";
        }
        if (g_plan.valid) {
            out += L"每日经验：" + Num1(g_plan.total) + L" EXP\n";
            swprintf_s(line, L"预计达成：%d 天（%04d.%02d.%02d）\n",
                       g_plan.days, g_plan.date.wYear, g_plan.date.wMonth, g_plan.date.wDay);
            out += line;
        }
    } else {
        out += g_calc.error.empty() ? L"请先输入有效的好感等级。" : g_calc.error;
        out += L"\n";
    }
    out += L"—— 本地计算，数据仅供参考";
    return out;
}

static void CopySummary() {
    std::wstring text = BuildSummary();
    if (!OpenClipboard(g_hwnd)) return;
    EmptyClipboard();
    size_t bytes = (text.size() + 1) * sizeof(wchar_t);
    HGLOBAL mem = GlobalAlloc(GMEM_MOVEABLE, bytes);
    if (mem) {
        void* dst = GlobalLock(mem);
        if (dst) {
            memcpy(dst, text.c_str(), bytes);
            GlobalUnlock(mem);
            SetClipboardData(CF_UNICODETEXT, mem);
        } else {
            GlobalFree(mem);
        }
    }
    CloseClipboard();
    AddToast(L"计算结果已复制到剪贴板");
}

// =============================================================================
//  Layout
// =============================================================================
static void BuildLayout() {
    const float contentX = 258.0f;
    const float contentW = 894.0f;

    g_rInputCard = { contentX, 132.0f, 408.0f, 340.0f };
    g_rResultCard = { contentX + 424.0f, 132.0f, 470.0f, 340.0f };
    g_rGiftCard = { contentX, 488.0f, contentW, 288.0f };

    g_rPlanSettings = { contentX, 132.0f, 366.0f, 644.0f };
    g_rPlanHero = { contentX + 382.0f, 132.0f, 512.0f, 306.0f };
    g_rPlanBreak = { contentX + 382.0f, 454.0f, 512.0f, 322.0f };

    g_rHelpLeft = { contentX, 132.0f, 420.0f, 644.0f };
    g_rHelpRight = { contentX + 438.0f, 132.0f, 456.0f, 644.0f };

    g_rNav[0] = { 16.0f, 184.0f, 200.0f, 52.0f };
    g_rNav[1] = { 16.0f, 246.0f, 200.0f, 52.0f };
    g_rNav[2] = { 16.0f, 308.0f, 200.0f, 52.0f };

    g_rMin = { 1092.0f, 5.0f, 34.0f, 31.0f };
    g_rClose = { 1132.0f, 5.0f, 34.0f, 31.0f };

    // calculator fields
    g_rField[0] = { 24.0f, 72.0f, 150.0f, 58.0f };
    g_rField[1] = { 234.0f, 72.0f, 150.0f, 58.0f };
    g_rField[2] = { 24.0f, 162.0f, 360.0f, 48.0f };

    g_rPreset[0] = { 24.0f, 238.0f, 94.0f, 26.0f };
    g_rPreset[1] = { 124.0f, 238.0f, 94.0f, 26.0f };
    g_rPreset[2] = { 224.0f, 238.0f, 110.0f, 26.0f };
    g_rCalcButton = { 24.0f, 278.0f, 360.0f, 46.0f };
    g_rResetButton = { 330.0f, 12.0f, 54.0f, 26.0f };
    g_rCopyButton = { 786.0f, 16.0f, 88.0f, 28.0f };
    g_rPlanLinkButton = { 688.0f, 16.0f, 88.0f, 28.0f };

    // planner fields (relative to settings card origin added below)
    g_rField[3] = { 246.0f, 128.0f, 96.0f, 38.0f };  // pats
    g_rField[4] = { 24.0f, 300.0f, 150.0f, 44.0f };  // m1
    g_rField[5] = { 192.0f, 300.0f, 150.0f, 44.0f }; // m2
    g_rField[6] = { 24.0f, 420.0f, 150.0f, 44.0f };  // n1
    g_rField[7] = { 192.0f, 420.0f, 150.0f, 44.0f }; // n2

    g_rCraft[0] = { 156.0f, 202.0f, 58.0f, 36.0f };
    g_rCraft[1] = { 220.0f, 202.0f, 58.0f, 36.0f };
    g_rCraft[2] = { 284.0f, 202.0f, 58.0f, 36.0f };

    g_rToggle = { 270.0f, 60.0f, 58.0f, 30.0f };
    g_rPlanButton = { 24.0f, 582.0f, 318.0f, 46.0f };

    g_rHelpAction = { 278.0f, 710.0f, 140.0f, 36.0f };
}

static UIRect FieldScreenRect(int index) {
    UIRect r = g_rField[index];
    if (index >= 3) {
        r.x += g_rPlanSettings.x;
        r.y += g_rPlanSettings.y;
    } else {
        r.x += g_rInputCard.x;
        r.y += g_rInputCard.y;
    }
    return r;
}

static UIRect CraftScreenRect(int index) {
    UIRect r = g_rCraft[index];
    r.x += g_rPlanSettings.x;
    r.y += g_rPlanSettings.y;
    return r;
}

static UIRect ToggleScreenRect() {
    UIRect r = g_rToggle;
    r.x += g_rPlanSettings.x;
    r.y += g_rPlanSettings.y;
    return r;
}

static UIRect PlanButtonScreenRect() {
    UIRect r = g_rPlanButton;
    r.x += g_rPlanSettings.x;
    r.y += g_rPlanSettings.y;
    return r;
}

static UIRect CopyButtonScreenRect() {
    UIRect r = g_rCopyButton;
    r.x += g_rGiftCard.x;
    r.y += g_rGiftCard.y;
    return r;
}

static UIRect PlanLinkButtonScreenRect() {
    UIRect r = g_rPlanLinkButton;
    r.x += g_rGiftCard.x;
    r.y += g_rGiftCard.y;
    return r;
}

static UIRect ResetButtonScreenRect() {
    UIRect r = g_rResetButton;
    r.x += g_rInputCard.x;
    r.y += g_rInputCard.y;
    return r;
}

// =============================================================================
//  Child edit management
// =============================================================================
static HWND EditHandle(int id) { return GetDlgItem(g_hwnd, id); }

static void PositionEdits() {
    struct EditPos { int id; int fieldIndex; float ix, iy, iw, ih; HFONT font; };
    const EditPos positions[] = {
        { ID_EDIT_CUR,    0, 14, 9,  100, 39, g_editFontBig },
        { ID_EDIT_TARGET, 1, 14, 9,  100, 39, g_editFontBig },
        { ID_EDIT_EXP,    2, 14, 8,  300, 31, g_editFontMed },
        { ID_EDIT_PATS,   3, 12, 6,   72, 26, g_editFontSmall },
        { ID_EDIT_M1,     4, 12, 8,  104, 28, g_editFontSmall },
        { ID_EDIT_M2,     5, 12, 8,  104, 28, g_editFontSmall },
        { ID_EDIT_N1,     6, 12, 8,  104, 28, g_editFontSmall },
        { ID_EDIT_N2,     7, 12, 8,  104, 28, g_editFontSmall },
    };

    for (const auto& p : positions) {
        HWND h = EditHandle(p.id);
        if (!h) continue;
        UIRect r = FieldScreenRect(p.fieldIndex);
        MoveWindow(h, PI(r.x + p.ix), PI(r.y + p.iy), PI(p.iw), PI(p.ih), TRUE);
        SendMessageW(h, WM_SETFONT, (WPARAM)p.font, TRUE);
        SendMessageW(h, EM_SETMARGINS, EC_LEFTMARGIN | EC_RIGHTMARGIN, MAKELPARAM(0, 0));
        ShowWindow(h, (g_page == PAGE_CALC && p.fieldIndex < 3) ||
                      (g_page == PAGE_PLAN && p.fieldIndex >= 3) ? SW_SHOW : SW_HIDE);
        if (p.id == ID_EDIT_PATS) EnableWindow(h, g_implemented ? TRUE : FALSE);
    }
}

static void CreateEdits() {
    struct EditSpec { int id; int maxLen; };
    const EditSpec specs[] = {
        { ID_EDIT_CUR, 3 }, { ID_EDIT_EXP, 6 }, { ID_EDIT_TARGET, 3 },
        { ID_EDIT_PATS, 2 }, { ID_EDIT_M1, 2 }, { ID_EDIT_M2, 2 },
        { ID_EDIT_N1, 2 }, { ID_EDIT_N2, 2 },
    };

    for (const auto& spec : specs) {
        const wchar_t* initial = L"0";
        if (spec.id == ID_EDIT_CUR) initial = L"1";
        else if (spec.id == ID_EDIT_TARGET) initial = L"100";
        else if (spec.id == ID_EDIT_PATS) initial = L"3";
        else if (spec.id == ID_EDIT_M1) initial = L"5";
        else if (spec.id == ID_EDIT_M2) initial = L"2";
        else if (spec.id == ID_EDIT_N1 || spec.id == ID_EDIT_N2) initial = L"1";

        HWND h = CreateWindowExW(0, L"EDIT", initial,
                                 WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | ES_NUMBER | ES_CENTER,
                                 0, 0, 10, 10, g_hwnd, (HMENU)(INT_PTR)spec.id,
                                 g_hinst, nullptr);
        if (!h) continue;
        SendMessageW(h, EM_SETLIMITTEXT, spec.maxLen, 0);
        SendMessageW(h, EM_SETMARGINS, EC_LEFTMARGIN | EC_RIGHTMARGIN, MAKELPARAM(0, 0));
        SetWindowTheme(h, L" ", L" ");
        SetWindowLongPtrW(h, GWLP_USERDATA, spec.id);
        SetWindowSubclass(h, [](HWND hwnd, UINT msg, WPARAM wp, LPARAM lp, UINT_PTR, DWORD_PTR) -> LRESULT {
            if (msg == WM_KEYDOWN && wp == VK_RETURN) {
                PostMessageW(g_hwnd, WM_APP_PRIMARY, 0, 0);
                return 0;
            }
            if (msg == WM_KEYDOWN && wp == VK_ESCAPE) {
                SetFocus(g_hwnd);
                return 0;
            }
            if (msg == WM_CHAR && (wp == VK_RETURN || wp == VK_ESCAPE)) return 0;
            if (msg == WM_KEYDOWN && wp == VK_TAB) {
                int ids[5] = { ID_EDIT_CUR, ID_EDIT_EXP, ID_EDIT_TARGET,
                               ID_EDIT_PATS, ID_EDIT_M1 };
                int count = 0;
                if (g_page == PAGE_CALC) {
                    ids[0] = ID_EDIT_CUR;
                    ids[1] = ID_EDIT_EXP;
                    ids[2] = ID_EDIT_TARGET;
                    count = 3;
                } else if (g_page == PAGE_PLAN) {
                    ids[0] = ID_EDIT_PATS;
                    ids[1] = ID_EDIT_M1;
                    ids[2] = ID_EDIT_M2;
                    ids[3] = ID_EDIT_N1;
                    ids[4] = ID_EDIT_N2;
                    count = 5;
                }
                if (count > 0) {
                    int current = GetDlgCtrlID(hwnd);
                    int index = 0;
                    for (int i = 0; i < count; ++i) {
                        if (ids[i] == current) { index = i; break; }
                    }
                    bool shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
                    for (int step = 0; step < count; ++step) {
                        index = (index + (shift ? -1 : 1) + count) % count;
                        HWND next = EditHandle(ids[index]);
                        if (next && IsWindowVisible(next) && IsWindowEnabled(next)) {
                            SetFocus(next);
                            SendMessageW(next, EM_SETSEL, 0, -1);
                            break;
                        }
                    }
                }
                return 0;
            }
            if (msg == WM_SETFOCUS || msg == WM_KILLFOCUS) {
                InvalidateRect(g_hwnd, nullptr, FALSE);
            }
            return DefSubclassProc(hwnd, msg, wp, lp);
        }, 1, 0);
    }
}

// =============================================================================
//  Drawing - chrome and sidebar
// =============================================================================
static void DrawAppIcon(Graphics& g, RectF r) {
    DrawImageFit(g, g_imgApp, r);
}

static void DrawTitleBar(Graphics& g) {
    LinearGradientBrush bg(RectF(0, 0, (float)BASE_W, (float)TITLE_H),
                           Color(255, 253, 249, 241), Color(255, 250, 245, 234),
                           LinearGradientModeVertical);
    g.FillRectangle(&bg, RectF(0, 0, (float)BASE_W, (float)TITLE_H));
    Line(g, 0, TITLE_H - 0.5f, (float)BASE_W, TITLE_H - 0.5f, Color(255, 226, 222, 213), 1.0f);

    DrawAppIcon(g, RectF(16, 10, 22, 22));
    Text(g, L"蔚蓝档案 · 好感计算器", RectF(46, 0, 310, TITLE_H), g_fSmallBold, C_INK);
    Text(g, L"SENSEI'S GIFT LAB", RectF(310, 0, 160, TITLE_H), g_fTiny, C_FAINT);
    Text(g, L"本地计算 · 无需联网", RectF(930, 0, 145, TITLE_H), g_fTiny, C_MUTED,
         StringAlignmentFar, StringAlignmentCenter);

    // minimize
    bool hovMin = g_hover == 1;
    bool hovClose = g_hover == 2;
    if (hovMin) FillRound(g, g_rMin.R(), 8, Color(255, 235, 242, 248));
    if (hovClose) FillRound(g, g_rClose.R(), 8, Color(255, 248, 224, 229));
    Pen pMin(hovMin ? C_BLUE : C_INK_SOFT, 1.4f);
    g.DrawLine(&pMin, 1103, 20, 1115, 20);
    Color closeColor = hovClose ? C_PINK_DARK : C_INK_SOFT;
    Pen pClose(closeColor, 1.5f);
    g.DrawLine(&pClose, 1142, 14, 1156, 27);
    g.DrawLine(&pClose, 1156, 14, 1142, 27);
}

static void NavIcon(Graphics& g, int index, RectF r, const Color& c) {
    Pen pen(c, 1.5f);
    pen.SetLineJoin(LineJoinRound);
    if (index == 0) {
        g.DrawRectangle(&pen, r.X + 1, r.Y + 5, r.Width - 2, r.Height - 7);
        g.DrawLine(&pen, r.X + r.Width * 0.5f, r.Y + 5, r.X + r.Width * 0.5f, r.Y + r.Height - 2);
        g.DrawLine(&pen, r.X + 1, r.Y + 12, r.X + r.Width - 1, r.Y + 12);
        g.DrawLine(&pen, r.X + 5, r.Y + 3, r.X + 7, r.Y + 5);
        g.DrawLine(&pen, r.X + r.Width - 5, r.Y + 3, r.X + r.Width - 7, r.Y + 5);
    } else if (index == 1) {
        g.DrawRectangle(&pen, r.X + 2, r.Y + 3, r.Width - 4, r.Height - 5);
        g.DrawLine(&pen, r.X + 2, r.Y + 10, r.X + r.Width - 2, r.Y + 10);
        g.DrawLine(&pen, r.X + 7, r.Y + 1, r.X + 7, r.Y + 6);
        g.DrawLine(&pen, r.X + r.Width - 7, r.Y + 1, r.X + r.Width - 7, r.Y + 6);
        Dot(g, r.X + 8, r.Y + 15, 1.5f, c);
    } else {
        g.DrawArc(&pen, r.X + 2, r.Y + 3, r.Width - 4, r.Height - 4, 180, 180);
        g.DrawArc(&pen, r.X + 2, r.Y + 3, r.Width - 4, r.Height - 4, 0, 180);
        g.DrawLine(&pen, r.X + r.Width * 0.5f, r.Y + 4, r.X + r.Width * 0.5f, r.Y + r.Height - 3);
    }
}

static void DrawSidebar(Graphics& g) {
    LinearGradientBrush bg(RectF(0, TITLE_H, SIDEBAR_W, BASE_H - TITLE_H),
                           C_SIDEBAR, Color(255, 246, 239, 226),
                           LinearGradientModeVertical);
    g.FillRectangle(&bg, RectF(0, TITLE_H, SIDEBAR_W, BASE_H - TITLE_H));
    Line(g, SIDEBAR_W - 0.5f, TITLE_H, SIDEBAR_W - 0.5f, (float)BASE_H, Color(255, 227, 220, 206), 1);

    if (g_imgSidebar) {
        DrawImageAlpha(g, g_imgSidebar, RectF(0, 470, 232, 330), 100);
    }

    // brand
    DrawAppIcon(g, RectF(22, 66, 58, 58));
    Text(g, L"S C H A L E", RectF(92, 66, 130, 15), g_fTinyBold, C_BLUE);
    Text(g, L"好感事务所", RectF(90, 78, 130, 26), g_fBrand, C_INK);
    Text(g, L"GIFT & BOND", RectF(92, 107, 130, 16), g_fTiny, C_MUTED);

    Line(g, 22, 146, 210, 146, Color(255, 228, 221, 207), 1.0f);
    Text(g, L"WORKSPACE", RectF(24, 158, 120, 16), g_fTinyBold, C_FAINT);

    const wchar_t* labels[3] = { L"礼物计算", L"达成规划", L"计算说明" };
    const wchar_t* shortcuts[3] = { L"01", L"02", L"03" };
    for (int i = 0; i < 3; ++i) {
        bool active = g_page == i;
        bool hover = g_hover == 100 + i;
        RectF r = g_rNav[i].R();
        if (active) {
            GradientRect(g, r, 14, Color(255, 74, 157, 218), Color(255, 42, 120, 190),
                         LinearGradientModeHorizontal);
            FillRound(g, RectF(r.X, r.Y + 14, 4, 24), 2, C_GOLD);
            // soft highlight
            FillRound(g, RectF(r.X + 10, r.Y + 5, r.Width - 20, 16), 8, Color(28, 255, 255, 255));
        } else if (hover) {
            FillRound(g, r, 14, Color(255, 242, 234, 221));
        }
        Color fg = active ? C_WHITE : C_INK_SOFT;
        NavIcon(g, i, RectF(r.X + 22, r.Y + 15, 22, 22), fg);
        Text(g, labels[i], RectF(r.X + 58, r.Y, 110, r.Height), g_fBodyBold, fg,
             StringAlignmentNear, StringAlignmentCenter);
        Text(g, shortcuts[i], RectF(r.X + r.Width - 34, r.Y, 20, r.Height), g_fTinyBold,
             active ? Color(200, 255, 255, 255) : C_FAINT,
             StringAlignmentFar, StringAlignmentCenter);
    }

    Line(g, 22, 384, 210, 384, Color(255, 228, 221, 207), 1.0f);

    // little data card
    Panel(g, RectF(18, 400, 196, 148), 18, Color(255, 255, 251, 243), Color(255, 238, 226, 201), false);
    Text(g, L"DATA CARD", RectF(34, 414, 130, 14), g_fTinyBold, C_GOLD_DARK);
    Text(g, L"关系等级上限", RectF(34, 436, 120, 16), g_fSmall, C_MUTED);
    Text(g, L"100", RectF(116, 430, 78, 24), g_fNum, C_INK, StringAlignmentFar);
    Line(g, 34, 462, 196, 462, Color(255, 236, 228, 213), 1);
    Text(g, L"Lv.1 → 100 总经验", RectF(34, 472, 140, 16), g_fSmall, C_MUTED);
    Text(g, L"240,225", RectF(34, 490, 160, 24), g_fNum, C_INK);
    Text(g, L"单件礼物 15 — 240 EXP", RectF(34, 518, 166, 16), g_fTiny, C_FAINT);

    // bottom note
    Panel(g, RectF(18, 574, 196, 154), 18, Color(255, 255, 251, 241), Color(255, 238, 225, 199), false);
    Star(g, 42, 600, 10, C_GOLD, C_NAVY, 1.2f);
    Text(g, L"SENSEI TIP", RectF(58, 591, 130, 16), g_fTinyBold, C_GOLD_DARK);
    Text(g, L"如果忘了当前经验，\n填 0 就是最保守的估算。", RectF(34, 616, 162, 58),
         g_fSmall, C_INK_SOFT, StringAlignmentNear, StringAlignmentNear, true);
    Text(g, L"数据以游戏内为准", RectF(34, 696, 160, 16), g_fTiny, C_FAINT);

    Text(g, L"v2.0  ·  FAN-MADE", RectF(22, 760, 190, 18), g_fTiny, C_FAINT);
}

static void PageHeader(Graphics& g, const wchar_t* title, const wchar_t* subtitle) {
    Text(g, title, RectF(258, 56, 700, 42), g_fH1, C_INK);
    Text(g, subtitle, RectF(258, 97, 700, 22), g_fBody, C_MUTED);
    // top-right small badge
    UIRect badge = { 1032, 64, 118, 30 };
    FillRound(g, badge.R(), 15, Color(255, 255, 252, 242));
    StrokeRound(g, badge.R(), 15, Color(255, 235, 224, 199), 1);
    Dot(g, 1048, 79, 3, C_MINT);
    Text(g, L"RELATION / 100", RectF(1057, 64, 86, 30), g_fTinyBold, C_MUTED,
         StringAlignmentNear, StringAlignmentCenter);
}

static void SectionBadge(Graphics& g, float x, float y, const wchar_t* number) {
    FillRound(g, RectF(x, y, 27, 18), 6, C_GOLD);
    Text(g, number, RectF(x, y, 27, 18), g_fTinyBold, C_NAVY,
         StringAlignmentCenter, StringAlignmentCenter);
}

// =============================================================================
//  Drawing - calculator page
// =============================================================================
static void DrawField(Graphics& g, int index, const wchar_t* suffix, bool big) {
    UIRect r = FieldScreenRect(index);
    HWND edit = nullptr;
    int id = 0;
    if (index == 0) { edit = EditHandle(ID_EDIT_CUR); id = ID_EDIT_CUR; }
    if (index == 1) { edit = EditHandle(ID_EDIT_TARGET); id = ID_EDIT_TARGET; }
    if (index == 2) { edit = EditHandle(ID_EDIT_EXP); id = ID_EDIT_EXP; }
    if (index == 3) { edit = EditHandle(ID_EDIT_PATS); id = ID_EDIT_PATS; }
    if (index == 4) { edit = EditHandle(ID_EDIT_M1); id = ID_EDIT_M1; }
    if (index == 5) { edit = EditHandle(ID_EDIT_M2); id = ID_EDIT_M2; }
    if (index == 6) { edit = EditHandle(ID_EDIT_N1); id = ID_EDIT_N1; }
    if (index == 7) { edit = EditHandle(ID_EDIT_N2); id = ID_EDIT_N2; }
    bool focused = edit && GetFocus() == edit;
    bool disabled = (index == 3 && !g_implemented && g_page == PAGE_PLAN);
    Color fill = disabled ? Color(255, 243, 244, 246)
                          : (focused ? C_FIELD_FOCUS : C_FIELD);
    Color border = disabled ? C_LINE : (focused ? C_BLUE_LIGHT : C_LINE_BLUE);
    FillRound(g, r.R(), 13, fill);
    StrokeRound(g, r.R(), 13, border, focused ? 1.8f : 1.0f);
    if (suffix && *suffix) {
        float suffixW = big ? 24.0f : 22.0f;
        float suffixX = r.x + r.w - 34.0f;
        if (index == 2) {
            suffixW = 38.0f;
            suffixX = r.x + r.w - 46.0f;
        }
        Text(g, suffix, RectF(suffixX, r.y, suffixW, r.h),
             g_fSmall, disabled ? C_FAINT : (focused ? C_BLUE_DARK : C_FAINT),
             StringAlignmentFar, StringAlignmentCenter);
    }
}

static void DrawInputCard(Graphics& g) {
    RectF r = g_rInputCard.R();
    Panel(g, r, 22, C_CARD, C_LINE);
    SectionBadge(g, r.X + 22, r.Y + 17, L"01");
    Text(g, L"设定目标", RectF(r.X + 58, r.Y + 12, 200, 26), g_fH3, C_INK);
    Text(g, L"输入当前进度，看看还差多少", RectF(r.X + 58, r.Y + 34, 220, 16),
         g_fTiny, C_MUTED);

    UIRect reset = ResetButtonScreenRect();
    bool resetHover = g_hover == 8;
    if (resetHover) FillRound(g, reset.R(), 8, Color(255, 240, 246, 252));
    Text(g, L"重置", reset.R(), g_fTinyBold, resetHover ? C_BLUE : C_MUTED,
         StringAlignmentCenter, StringAlignmentCenter);

    Text(g, L"当前等级", RectF(r.X + 24, r.Y + 52, 120, 18), g_fSmall, C_MUTED);
    Text(g, L"目标等级", RectF(r.X + 234, r.Y + 52, 120, 18), g_fSmall, C_MUTED);

    DrawField(g, 0, L"级", true);
    DrawField(g, 1, L"级", true);

    // arrow between levels
    float ax = r.X + 204, ay = r.Y + 101;
    Dot(g, ax, ay, 13, Color(255, 237, 245, 252));
    Pen arrow(C_BLUE, 1.4f);
    g.DrawLine(&arrow, ax - 5, ay, ax + 4, ay);
    g.DrawLine(&arrow, ax + 1, ay - 4, ax + 5, ay);
    g.DrawLine(&arrow, ax + 1, ay + 4, ax + 5, ay);

    Text(g, L"当前等级经验", RectF(r.X + 24, r.Y + 144, 180, 16), g_fSmall, C_MUTED);
    Text(g, L"不确定填 0", RectF(r.X + 238, r.Y + 144, 146, 16), g_fTiny, C_FAINT,
         StringAlignmentFar);
    DrawField(g, 2, L"EXP", false);

    // live hint
    int curLevel = Clampi(ReadInt(g_hwnd, ID_EDIT_CUR, 1), 1, 100);
    long long currentNeed = (curLevel >= 100) ? 0 : LEVEL_EXP[curLevel];
    int curExp = Clampi(ReadInt(g_hwnd, ID_EDIT_EXP, 0), 0, (int)std::max(0LL, currentNeed));
    std::wstring hint = L"本等级进度 " + Num(curExp) + L" / " + Num(currentNeed) +
                        L" · 会从总需求中扣除";
    if (g_calc.error.empty()) {
        Text(g, hint, RectF(r.X + 24, r.Y + 216, 350, 18), g_fTiny, C_FAINT);
    }

    const wchar_t* presetText[3] = { L"新手 1→100", L"日常 30→50", L"冲刺 90→100" };
    for (int i = 0; i < 3; ++i) {
        UIRect p = g_rPreset[i];
        p.x += r.X; p.y += r.Y;
        bool hov = g_hover == 10 + i;
        FillRound(g, p.R(), 13, hov ? Color(255, 233, 246, 255) : Color(255, 248, 251, 254));
        StrokeRound(g, p.R(), 13, hov ? C_BLUE_LIGHT : C_LINE_BLUE, 1);
        Text(g, presetText[i], p.R(), g_fTinyBold, hov ? C_BLUE_DARK : C_INK_SOFT,
             StringAlignmentCenter, StringAlignmentCenter);
    }

    // calculate button
    UIRect b = g_rCalcButton;
    b.x += r.X; b.y += r.Y;
    bool hover = g_hover == 20;
    RectF br = b.R();
    Shadow(g, br, 14, hover ? 5.0f : 3.0f, 38);
    GradientRect(g, br, 14, hover ? Color(255, 93, 176, 231) : Color(255, 73, 158, 220),
                 hover ? Color(255, 41, 124, 197) : Color(255, 39, 116, 187),
                 LinearGradientModeHorizontal);
    Star(g, br.X + 28, br.Y + br.Height * 0.5f, 7.5f, C_GOLD_LIGHT);
    Text(g, L"开始计算", RectF(br.X + 46, br.Y, 210, br.Height), g_fButton, C_WHITE,
         StringAlignmentNear, StringAlignmentCenter);
    Pen p(C_WHITE, 1.6f);
    g.DrawLine(&p, br.X + br.Width - 34, br.Y + 19, br.X + br.Width - 23, br.Y + 23);
    g.DrawLine(&p, br.X + br.Width - 34, br.Y + 27, br.X + br.Width - 23, br.Y + 23);

    if (!g_calc.error.empty()) {
        Text(g, g_calc.error, RectF(r.X + 24, r.Y + 214, 360, 18), g_fTiny, C_PINK_DARK,
             StringAlignmentNear, StringAlignmentCenter, false, true);
    }
}

static void DrawResultCard(Graphics& g) {
    RectF r = g_rResultCard.R();
    Shadow(g, r, 22, 4, 34);
    GraphicsPath clip;
    AddRoundRect(clip, r, 22);
    g.SetClip(&clip);

    LinearGradientBrush bg(r, Color(255, 55, 137, 207), Color(255, 24, 55, 102),
                           LinearGradientModeVertical);
    g.FillRectangle(&bg, r);

    // soft glows
    for (int i = 0; i < 3; ++i) {
        float rr = 210.0f - i * 52.0f;
        SolidBrush glow(Color((BYTE)(13 + i * 5), 139, 208, 247));
        g.FillEllipse(&glow, r.X + r.Width - rr - 20, r.Y - rr * 0.45f, rr * 1.5f, rr * 1.5f);
    }
    // diagonal lines
    Pen stripe(Color(16, 255, 255, 255), 1.0f);
    for (float x = r.X - 100; x < r.X + r.Width + 200; x += 24) {
        g.DrawLine(&stripe, x, r.Y + r.Height, x + 220, r.Y - 60);
    }
    // dotted halftone corner
    for (int i = 0; i < 9; ++i) {
        for (int j = 0; j < 5; ++j) {
            Dot(g, r.X + 22 + i * 15, r.Y + r.Height - 20 - j * 13, 1.1f,
                Color((BYTE)(25 + i * 2), 255, 255, 255));
        }
    }
    // halo decoration
    Halo(g, r.X + r.Width - 78, r.Y + 92, 118, 47, Color(55, 255, 221, 139), 1.2f);
    Star(g, r.X + r.Width - 32, r.Y + 34, 10, Color(210, 255, 221, 139));

    // route pill
    std::wstring route = L"Lv." + IntText(g_calc.valid ? g_calc.cur : 1) + L"  →  Lv." +
                         IntText(g_calc.valid ? g_calc.target : 100);
    float rw = std::max(128.0f, Measure(g, route, g_fSmallBold) + 30);
    FillRound(g, RectF(r.X + 22, r.Y + 18, rw, 28), 14, Color(38, 255, 255, 255));
    StrokeRound(g, RectF(r.X + 22, r.Y + 18, rw, 28), 14, Color(60, 255, 255, 255), 1);
    Text(g, route, RectF(r.X + 22, r.Y + 18, rw, 28), g_fSmallBold, C_WHITE,
         StringAlignmentCenter, StringAlignmentCenter);

    // art
    if (g_imgHero) {
        DrawImageAlpha(g, g_imgHero, RectF(r.X + 326, r.Y + 44, 130, 130), 245);
    }

    Text(g, L"还需好感经验 · EXP", RectF(r.X + 24, r.Y + 56, 280, 16), g_fTinyBold,
         Color(215, 235, 249, 255));
    long long shown = g_animating ? (long long)std::llround(g_displayRemaining)
                                  : (g_calc.valid ? g_calc.remaining : 0);
    std::wstring big = Num(shown);
    Text(g, big, RectF(r.X + 24, r.Y + 72, 305, 58), g_fNumHuge, C_WHITE);
    if (g_calc.valid) {
        Text(g, L"将当前经验扣除后", RectF(r.X + 24, r.Y + 130, 220, 16), g_fTiny,
             Color(200, 229, 245, 255));
    }

    // current-level progress
    float barX = r.X + 24, barY = r.Y + 150, barW = 280, barH = 71;
    int curLevel = g_calc.valid ? g_calc.cur : 1;
    int curExp = g_calc.valid ? g_calc.curExp : 0;
    int need = (curLevel >= 100) ? 0 : LEVEL_EXP[curLevel];
    float ratio = need > 0 ? Clampf((float)curExp / need, 0.0f, 1.0f) : 1.0f;
    Text(g, L"当前等级进度", RectF(barX, barY - 18, 130, 16), g_fTiny,
         Color(205, 230, 246, 255));
    Text(g, Num(curExp) + L" / " + Num(need), RectF(barX + 140, barY - 18, 140, 16),
         g_fTiny, Color(240, 250, 255, 255), StringAlignmentFar);
    FillRound(g, RectF(barX, barY, barW, 7), 3.5f, Color(60, 255, 255, 255));
    if (ratio > 0) {
        FillRound(g, RectF(barX, barY, std::max(7.0f, barW * ratio), 7), 3.5f,
                  Color(255, 255, 221, 139));
    }

    // stats
    float sy = r.Y + 220, sh = 98;
    float sw = (r.Width - 48 - 16) / 3.0f;
    const wchar_t* labels[3] = { L"升级跨度", L"当前累计", L"目标累计" };
    std::wstring values[3] = {
        IntText(g_calc.valid ? g_calc.span : 0) + L" 级",
        Num(g_calc.valid ? g_calc.totalCurrent : 0),
        Num(g_calc.valid ? g_calc.totalTarget : 0)
    };
    for (int i = 0; i < 3; ++i) {
        RectF box(r.X + 24 + i * (sw + 8), sy, sw, sh);
        FillRound(g, box, 14, Color(25, 255, 255, 255));
        StrokeRound(g, box, 14, Color(32, 255, 255, 255), 1);
        Text(g, labels[i], RectF(box.X + 12, box.Y + 12, box.Width - 24, 16), g_fTiny,
             Color(200, 230, 247, 255));
        Text(g, values[i], RectF(box.X + 12, box.Y + 34, box.Width - 24, 32), g_fNum,
             C_WHITE);
        Text(g, i == 0 ? L"LEVELS" : L"EXP", RectF(box.X + 12, box.Y + 70, box.Width - 24, 14),
             g_fTiny, Color(185, 224, 244, 255));
    }

    g.ResetClip();
}

static void CopyGlyph(Graphics& g, RectF r, const Color& c);

static void DrawGiftCard(Graphics& g) {
    RectF r = g_rGiftCard.R();
    Panel(g, r, 22, C_CARD, C_LINE);
    SectionBadge(g, r.X + 20, r.Y + 17, L"02");
    Text(g, L"礼物换算", RectF(r.X + 56, r.Y + 11, 160, 26), g_fH3, C_INK);
    Text(g, L"以下数量均按单一礼物补足，已向上取整", RectF(r.X + 56, r.Y + 33, 330, 16),
         g_fTiny, C_MUTED);

    // text action buttons
    UIRect copy = CopyButtonScreenRect();
    bool copyHover = g_hover == 30;
    FillRound(g, copy.R(), 9, copyHover ? Color(255, 231, 245, 254) : Color(255, 248, 251, 254));
    StrokeRound(g, copy.R(), 9, copyHover ? C_BLUE_LIGHT : C_LINE_BLUE, 1);
    CopyGlyph(g, RectF(copy.x + 12, copy.y + 9, 11, 11), copyHover ? C_BLUE : C_MUTED);
    Text(g, L"复制", RectF(copy.x + 28, copy.y, 52, copy.h), g_fTinyBold,
         copyHover ? C_BLUE_DARK : C_INK_SOFT, StringAlignmentNear, StringAlignmentCenter);

    UIRect plan = PlanLinkButtonScreenRect();
    bool planHover = g_hover == 31;
    FillRound(g, plan.R(), 9, planHover ? Color(255, 236, 247, 255) : Color(255, 248, 251, 254));
    StrokeRound(g, plan.R(), 9, planHover ? C_BLUE_LIGHT : C_LINE_BLUE, 1);
    Text(g, L"规划 →", plan.R(), g_fTinyBold, planHover ? C_BLUE_DARK : C_INK_SOFT,
         StringAlignmentCenter, StringAlignmentCenter);

    // grid
    float startX = r.X + 20;
    float startY = r.Y + 58;
    float gap = 12;
    float cardW = (r.Width - 40 - gap * 3) / 4.0f;
    float cardH = 96;
    for (int i = 0; i < 8; ++i) {
        int col = i % 4;
        int row = i / 4;
        RectF c(startX + col * (cardW + gap), startY + row * (cardH + 10), cardW, cardH);
        Color tint;
        Color border;
        if (ITEMS[i].kind == 0) { tint = Color(255, 255, 249, 251); border = Color(255, 247, 225, 232); }
        else if (ITEMS[i].kind == 1) { tint = Color(255, 247, 251, 255); border = Color(255, 227, 238, 249); }
        else if (ITEMS[i].kind == 2) { tint = Color(255, 251, 248, 255); border = Color(255, 235, 227, 249); }
        else { tint = Color(255, 247, 253, 249); border = Color(255, 226, 241, 232); }
        FillRound(g, c, 16, tint);
        StrokeRound(g, c, 16, border, 1);
        DrawImageFit(g, g_imgItems[i], RectF(c.X + 9, c.Y + 22, 52, 52));
        Text(g, ITEMS[i].name, RectF(c.X + 68, c.Y + 11, c.Width - 78, 22),
             g_fSmallBold, C_INK, StringAlignmentNear, StringAlignmentCenter, false, true);
        std::wstring expText = (ITEMS[i].kind == 3)
            ? L"期望 32.5 EXP / 次"
            : Num((long long)ITEMS[i].exp) + L" EXP / " + ITEMS[i].unit;
        Text(g, expText, RectF(c.X + 68, c.Y + 32, c.Width - 78, 16), g_fTiny, C_MUTED);
        std::wstring count = Num(g_calc.valid ? g_calc.count[i] : 0);
        Text(g, count, RectF(c.X + 68, c.Y + 49, c.Width - 104, 30), g_fNumBig, C_INK,
             StringAlignmentFar);
        Text(g, ITEMS[i].unit, RectF(c.X + c.Width - 34, c.Y + 49, 24, 30), g_fTiny, C_MUTED,
             StringAlignmentFar, StringAlignmentCenter);
    }
}

static void CopyGlyph(Graphics& g, RectF r, const Color& c) {
    Pen p(c, 1.2f);
    g.DrawRectangle(&p, r.X + 3, r.Y + 1, r.Width - 5, r.Height - 4);
    g.DrawRectangle(&p, r.X + 1, r.Y + 3, r.Width - 5, r.Height - 4);
}

static void DrawCalculator(Graphics& g) {
    PageHeader(g, L"好感度计算器", L"把每一次心动，换算成看得见的距离。");
    DrawInputCard(g);
    DrawResultCard(g);
    DrawGiftCard(g);

    // toast
    if (!g_toast.empty()) {
        float tw = std::min(380.0f, Measure(g, g_toast, g_fSmallBold) + 54);
        RectF tr((BASE_W - tw) * 0.5f, BASE_H - 52, tw, 34);
        FillRound(g, tr, 17, Color(242, 40, 54, 79));
        Dot(g, tr.X + 18, tr.Y + 17, 4, C_MINT);
        Text(g, g_toast, RectF(tr.X + 30, tr.Y, tw - 40, tr.Height), g_fSmallBold, C_WHITE,
             StringAlignmentNear, StringAlignmentCenter);
    }
}

// =============================================================================
//  Drawing - planner page
// =============================================================================
static void DrawToggle(Graphics& g, UIRect r, bool on, bool hover) {
    FillRound(g, r.R(), r.h * 0.5f, on ? Color(255, 99, 186, 219) : Color(255, 218, 224, 230));
    if (hover) StrokeRound(g, r.R(), r.h * 0.5f, C_BLUE_LIGHT, 1.4f);
    float knob = r.h - 8;
    float kx = on ? r.x + r.w - knob - 4 : r.x + 4;
    FillRound(g, RectF(kx, r.y + 4, knob, knob), knob * 0.5f, C_WHITE);
    if (on) Dot(g, kx + knob * 0.5f, r.y + r.h * 0.5f, 2, Color(255, 99, 186, 219));
}

static void DrawPlanner(Graphics& g) {
    PageHeader(g, L"达成天数规划", L"把礼物、摸头与课程表，折算成陪伴她的日子。");

    RectF sr = g_rPlanSettings.R();
    Panel(g, sr, 22, C_CARD, C_LINE);
    SectionBadge(g, sr.X + 22, sr.Y + 17, L"03");
    Text(g, L"每日获取", RectF(sr.X + 58, sr.Y + 11, 190, 26), g_fH3, C_INK);
    Text(g, L"按你的日常习惯估算", RectF(sr.X + 58, sr.Y + 33, 200, 16), g_fTiny, C_MUTED);

    // implemented switch
    Text(g, L"角色已实装", RectF(sr.X + 24, sr.Y + 54, 160, 20), g_fSmallBold, C_INK);
    Text(g, L"未实装时不计算摸头与课程表", RectF(sr.X + 24, sr.Y + 73, 230, 18), g_fTiny, C_FAINT);
    DrawToggle(g, ToggleScreenRect(), g_implemented, g_hover == 40);
    Text(g, g_implemented ? L"是" : L"否", RectF(sr.X + 266, sr.Y + 96, 60, 16), g_fTiny,
         g_implemented ? C_BLUE_DARK : C_MUTED, StringAlignmentCenter);

    Line(g, sr.X + 24, sr.Y + 116, sr.X + 342, sr.Y + 116, Color(255, 235, 231, 220), 1);

    // headpats
    Text(g, L"每天摸头次数", RectF(sr.X + 24, sr.Y + 130, 180, 24), g_fSmallBold,
         g_implemented ? C_INK : C_FAINT);
    Text(g, L"每次 +15 EXP", RectF(sr.X + 24, sr.Y + 150, 160, 16), g_fTiny, C_FAINT);
    DrawField(g, 3, L"次", false);

    // craft chips
    Text(g, L"每日制造次数", RectF(sr.X + 24, sr.Y + 184, 140, 22), g_fSmallBold, C_INK);
    Text(g, L"每次期望产出礼物", RectF(sr.X + 24, sr.Y + 225, 130, 16), g_fTiny, C_FAINT);
    const wchar_t* craftText[3] = { L"0", L"3", L"6" };
    for (int i = 0; i < 3; ++i) {
        UIRect cr = CraftScreenRect(i);
        bool on = g_craft == (i == 0 ? 0 : (i == 1 ? 3 : 6));
        bool hov = g_hover == 50 + i;
        FillRound(g, cr.R(), 10, on ? C_BLUE : (hov ? Color(255, 237, 247, 255) : Color(255, 248, 251, 254)));
        StrokeRound(g, cr.R(), 10, on ? C_BLUE : C_LINE_BLUE, 1);
        Text(g, craftText[i], cr.R(), g_fSmallBold, on ? C_WHITE : C_INK_SOFT,
             StringAlignmentCenter, StringAlignmentCenter);
    }

    Line(g, sr.X + 24, sr.Y + 256, sr.X + 342, sr.Y + 256, Color(255, 235, 231, 220), 1);

    // normal gift inventory
    Text(g, L"普通礼物库存", RectF(sr.X + 24, sr.Y + 268, 180, 22), g_fSmallBold, C_INK);
    Text(g, L"总计 35 个", RectF(sr.X + 248, sr.Y + 268, 94, 18), g_fTiny, C_FAINT,
         StringAlignmentFar);
    Text(g, L"微笑脸普通", RectF(sr.X + 24, sr.Y + 282, 120, 16), g_fTiny, C_MUTED);
    Text(g, L"大笑脸普通", RectF(sr.X + 192, sr.Y + 282, 120, 16), g_fTiny, C_MUTED);
    DrawField(g, 4, L"个", false);
    DrawField(g, 5, L"个", false);
    Text(g, L"其余按普通礼物 20 EXP 计算", RectF(sr.X + 24, sr.Y + 348, 310, 16), g_fTiny, C_FAINT);

    // purple gift inventory
    Text(g, L"紫色礼物库存", RectF(sr.X + 24, sr.Y + 368, 180, 22), g_fSmallBold, C_INK);
    Text(g, L"总计 13 个", RectF(sr.X + 248, sr.Y + 368, 94, 18), g_fTiny, C_FAINT,
         StringAlignmentFar);
    Text(g, L"紫色大笑脸", RectF(sr.X + 24, sr.Y + 388, 120, 16), g_fTiny, C_MUTED);
    Text(g, L"紫色爱心脸", RectF(sr.X + 192, sr.Y + 388, 120, 16), g_fTiny, C_MUTED);
    DrawField(g, 6, L"个", false);
    DrawField(g, 7, L"个", false);
    Text(g, L"其余按紫色礼物 120 EXP 计算", RectF(sr.X + 24, sr.Y + 468, 310, 16), g_fTiny, C_FAINT);

    // assumption note
    RectF note(sr.X + 20, sr.Y + 494, sr.Width - 40, 66);
    FillRound(g, note, 12, Color(255, 248, 243, 230));
    StrokeRound(g, note, 12, Color(255, 240, 226, 199), 1);
    Star(g, note.X + 16, note.Y + 19, 6, C_GOLD);
    Text(g, L"活动礼物按每月 2 次活动、2 次决战、\n1 次制约接触作战（8 紫 + 80 普）估算。",
         RectF(note.X + 28, note.Y + 9, note.Width - 38, 48), g_fTiny, C_MUTED,
         StringAlignmentNear, StringAlignmentNear, true);

    UIRect btn = PlanButtonScreenRect();
    bool hover = g_hover == 60;
    Shadow(g, btn.R(), 14, hover ? 4.0f : 3.0f, 32);
    GradientRect(g, btn.R(), 14, hover ? Color(255, 94, 176, 230) : Color(255, 70, 155, 218),
                 hover ? Color(255, 39, 122, 195) : Color(255, 37, 112, 183),
                 LinearGradientModeHorizontal);
    if (g_calc.valid) {
        Text(g, L"重新估算达成天数", btn.R(), g_fButton, C_WHITE,
             StringAlignmentCenter, StringAlignmentCenter);
    } else {
        Text(g, L"请先完成礼物计算", btn.R(), g_fButton, C_WHITE,
             StringAlignmentCenter, StringAlignmentCenter);
    }

    if (!g_plan.error.empty()) {
        Text(g, g_plan.error, RectF(sr.X + 24, sr.Y + 558, 318, 16), g_fTiny, C_PINK_DARK,
             StringAlignmentCenter, StringAlignmentCenter, false, true);
    }

    // hero card
    RectF hr = g_rPlanHero.R();
    Panel(g, hr, 24, Color(255, 255, 250, 239), Color(255, 239, 225, 194));
    Halo(g, hr.X + hr.Width - 116, hr.Y + 100, 145, 54, Color(45, 247, 196, 85), 1.2f);
    Halo(g, hr.X + hr.Width - 116, hr.Y + 100, 112, 38, Color(35, 247, 196, 85), 0.8f);
    // corner sparkles
    Star(g, hr.X + 34, hr.Y + 28, 9, C_GOLD);
    Star(g, hr.X + hr.Width - 34, hr.Y + 30, 7, Color(230, 239, 132, 164));

    Text(g, g_implemented ? L"预计达成" : L"预计攒礼", RectF(hr.X + 34, hr.Y + 24, 150, 18),
         g_fTinyBold, C_MUTED);
    if (g_plan.valid) {
        std::wstring daysText = Num(g_plan.days);
        float dw = Measure(g, daysText, g_fNumHuge);
        Text(g, daysText, RectF(hr.X + 34, hr.Y + 46, 180, 70), g_fNumHuge, C_BLUE_DARK);
        Text(g, L"天", RectF(hr.X + 38 + dw, hr.Y + 80, 34, 30), g_fH3, C_INK_SOFT);
        wchar_t dateBuf[96];
        swprintf_s(dateBuf, L"预计 %04d.%02d.%02d 达成 Lv.%d",
                   g_plan.date.wYear, g_plan.date.wMonth, g_plan.date.wDay, g_calc.target);
        Text(g, dateBuf, RectF(hr.X + 36, hr.Y + 124, 320, 22), g_fSmall, C_INK_SOFT);

        // comparison
        bool better = g_plan.altDays < g_plan.days;
        std::wstring cmp = better ? (L"礼物改造后 " + Num(g_plan.altDays) + L" 天 · 提前 " +
                                     Num(g_plan.days - g_plan.altDays) + L" 天")
                                  : L"已按当前方案估算";
        RectF chip(hr.X + 34, hr.Y + 158, 300, 34);
        FillRound(g, chip, 17, better ? Color(255, 229, 249, 241) : Color(255, 244, 240, 229));
        StrokeRound(g, chip, 17, better ? Color(255, 190, 234, 218) : Color(255, 235, 224, 201), 1);
        Dot(g, chip.X + 16, chip.Y + 17, 4, better ? C_MINT : C_GOLD);
        Text(g, cmp, RectF(chip.X + 28, chip.Y, chip.Width - 38, chip.Height), g_fTinyBold,
             better ? Color(255, 50, 145, 126) : C_MUTED, StringAlignmentNear, StringAlignmentCenter);

        Text(g, L"每日预计", RectF(hr.X + 34, hr.Y + 214, 100, 16), g_fTiny, C_MUTED);
        Text(g, Num1(g_plan.total) + L" EXP", RectF(hr.X + 100, hr.Y + 208, 160, 28),
             g_fNum, C_INK);
        Text(g, L"目标还差", RectF(hr.X + 34, hr.Y + 248, 100, 16), g_fTiny, C_MUTED);
        Text(g, Num(g_calc.remaining) + L" EXP", RectF(hr.X + 100, hr.Y + 242, 180, 26),
             g_fNum, C_INK);
    } else {
        Text(g, L"— —", RectF(hr.X + 34, hr.Y + 56, 180, 70), g_fNumHuge, C_FAINT);
        Text(g, L"完成礼物计算后，这里会出现预计天数。", RectF(hr.X + 36, hr.Y + 140, 300, 44),
             g_fSmall, C_MUTED, StringAlignmentNear, StringAlignmentNear, true);
    }

    // decorative calendar on the right
    RectF cal(hr.X + hr.Width - 148, hr.Y + 126, 94, 102);
    FillRound(g, cal, 14, Color(255, 255, 255, 255));
    StrokeRound(g, cal, 14, C_LINE_BLUE, 1);
    FillRound(g, RectF(cal.X, cal.Y, cal.Width, 24), 12, Color(255, 108, 181, 224));
    FillRound(g, RectF(cal.X, cal.Y + 14, cal.Width, 10), 0, Color(255, 108, 181, 224));
    Text(g, L"PLAN", RectF(cal.X, cal.Y, cal.Width, 24), g_fTinyBold, C_WHITE,
         StringAlignmentCenter, StringAlignmentCenter);
    for (int i = 0; i < 9; ++i) {
        int col = i % 3, row = i / 3;
        RectF cell(cal.X + 12 + col * 24, cal.Y + 36 + row * 20, 14, 12);
        Color cc = (i == std::min(8, std::max(0, (g_plan.valid ? g_plan.days : 0) % 9)))
                       ? C_GOLD : Color(255, 231, 240, 247);
        FillRound(g, cell, 4, cc);
    }

    // breakdown card
    RectF br = g_rPlanBreak.R();
    Panel(g, br, 22, C_CARD, C_LINE);
    Text(g, L"每日经验构成", RectF(br.X + 22, br.Y + 15, 200, 22), g_fH3, C_INK);
    Text(g, L"按当前输入折算", RectF(br.X + 22, br.Y + 37, 180, 16), g_fTiny, C_MUTED);
    Text(g, g_plan.valid ? Num1(g_plan.total) + L" / 天" : L"— / 天",
         RectF(br.X + br.Width - 160, br.Y + 18, 138, 22), g_fNum, C_BLUE_DARK,
         StringAlignmentFar);

    float chartX = br.X + 22, chartY = br.Y + 66, chartW = br.Width - 44, chartH = 14;
    FillRound(g, RectF(chartX, chartY, chartW, chartH), 7, Color(255, 241, 245, 249));
    if (g_plan.valid && g_plan.total > 0.001) {
        double parts[4] = { g_plan.activity, g_plan.craftExp, g_plan.patsExp, g_plan.courseExp };
        Color cols[4] = { C_BLUE, C_PURPLE, C_PINK, C_MINT };
        float cx = chartX;
        for (int i = 0; i < 4; ++i) {
            if (parts[i] <= 0.001) continue;
            float w = (float)(chartW * parts[i] / g_plan.total);
            if (w < 2) w = 2;
            if (cx + w > chartX + chartW) w = chartX + chartW - cx;
            FillRound(g, RectF(cx, chartY, std::max(2.0f, w), chartH), 7, cols[i]);
            cx += w;
        }
    }

    struct Legend { const wchar_t* name; Color color; double value; };
    Legend leg[4] = {
        { L"活动礼物", C_BLUE, g_plan.activity },
        { L"制造收益", C_PURPLE, g_plan.craftExp },
        { L"摸头", C_PINK, g_plan.patsExp },
        { L"课程表", C_MINT, g_plan.courseExp },
    };
    for (int i = 0; i < 4; ++i) {
        int col = i % 2, row = i / 2;
        float x = br.X + 22 + col * 238;
        float y = br.Y + 98 + row * 38;
        Dot(g, x + 5, y + 9, 5, leg[i].color);
        Text(g, leg[i].name, RectF(x + 16, y, 100, 18), g_fSmall, C_MUTED);
        Text(g, g_plan.valid ? Num1(leg[i].value) : L"0.0",
             RectF(x + 116, y, 100, 18), g_fSmallBold, C_INK);
    }

    // conversion panel
    RectF alt(br.X + 22, br.Y + 178, br.Width - 44, 68);
    FillRound(g, alt, 13, Color(255, 249, 246, 236));
    StrokeRound(g, alt, 13, Color(255, 240, 228, 205), 1);
    Text(g, L"将剩余普通礼物制作为大笑脸普通", RectF(alt.X + 14, alt.Y + 9, alt.Width - 28, 18),
         g_fTiny, C_MUTED);
    if (g_plan.valid) {
        Text(g, L"+" + Num1(g_plan.extra) + L" EXP / 天", RectF(alt.X + 14, alt.Y + 29, 200, 26),
             g_fNum, C_GOLD_DARK);
        Text(g, L"可提前 " + Num(g_plan.days - g_plan.altDays) + L" 天",
             RectF(alt.X + alt.Width - 134, alt.Y + 29, 120, 26), g_fSmallBold, C_BLUE_DARK,
             StringAlignmentFar);
    } else {
        Text(g, L"—", RectF(alt.X + 14, alt.Y + 29, 200, 26), g_fNum, C_FAINT);
    }

    Text(g, L"※ 课程表按 32.5 EXP/次 × 175/230 出现率估算；制造按每次期望礼物折算。",
         RectF(br.X + 22, br.Y + 260, br.Width - 44, 34), g_fTiny, C_FAINT,
         StringAlignmentNear, StringAlignmentNear, true);
    Text(g, L"实际掉落、暴击与角色偏好会造成偏差。",
         RectF(br.X + 22, br.Y + 292, br.Width - 44, 18), g_fTiny, C_FAINT);

    if (!g_toast.empty()) {
        float tw = std::min(380.0f, Measure(g, g_toast, g_fSmallBold) + 54);
        RectF tr((BASE_W - tw) * 0.5f, BASE_H - 52, tw, 34);
        FillRound(g, tr, 17, Color(242, 40, 54, 79));
        Dot(g, tr.X + 18, tr.Y + 17, 4, C_MINT);
        Text(g, g_toast, RectF(tr.X + 30, tr.Y, tw - 40, tr.Height), g_fSmallBold, C_WHITE,
             StringAlignmentNear, StringAlignmentCenter);
    }
}

// =============================================================================
//  Drawing - help page
// =============================================================================
static void StepRow(Graphics& g, float x, float y, const wchar_t* number,
                    const wchar_t* title, const wchar_t* body) {
    FillRound(g, RectF(x, y, 34, 34), 17, C_BLUE);
    Text(g, number, RectF(x, y, 34, 34), g_fTinyBold, C_WHITE,
         StringAlignmentCenter, StringAlignmentCenter);
    Text(g, title, RectF(x + 48, y - 2, 280, 24), g_fBodyBold, C_INK);
    Text(g, body, RectF(x + 48, y + 22, 300, 54), g_fSmall, C_MUTED,
         StringAlignmentNear, StringAlignmentNear, true);
}

static void DrawHelp(Graphics& g) {
    PageHeader(g, L"计算说明", L"让每一份礼物，都有据可依。");

    RectF lr = g_rHelpLeft.R();
    Panel(g, lr, 22, C_CARD, C_LINE);
    SectionBadge(g, lr.X + 22, lr.Y + 17, L"04");
    Text(g, L"三步上手", RectF(lr.X + 58, lr.Y + 11, 180, 26), g_fH3, C_INK);
    Text(g, L"从进度到礼物，再到天数", RectF(lr.X + 58, lr.Y + 33, 250, 16), g_fTiny, C_MUTED);

    StepRow(g, lr.X + 24, lr.Y + 76, L"1", L"填写当前进度",
            L"选择当前等级、目标等级；当前等级经验在游戏内的好感条上，忘了就填 0。");
    StepRow(g, lr.X + 24, lr.Y + 174, L"2", L"查看单一礼物需求",
            L"每张卡片都是“只用这一种礼物”时的数量，向上取整。可以按库存自由混搭。");
    StepRow(g, lr.X + 24, lr.Y + 272, L"3", L"估算达成天数",
            L"在达成规划里填写每天的摸头、制造与礼物库存，得到预计天数与日期。");

    RectF tip(lr.X + 22, lr.Y + 346, lr.Width - 44, 92);
    FillRound(g, tip, 14, Color(255, 250, 244, 231));
    StrokeRound(g, tip, 14, Color(255, 240, 226, 199), 1);
    Star(g, tip.X + 18, tip.Y + 20, 7, C_GOLD);
    Text(g, L"一个小提示", RectF(tip.X + 32, tip.Y + 9, 160, 20), g_fSmallBold, C_GOLD_DARK);
    Text(g, L"“当前经验”会被扣除。若忘记当前进度，填 0 会得到最保守的结果，不会低估所需礼物。",
         RectF(tip.X + 18, tip.Y + 32, tip.Width - 36, 50), g_fSmall, C_MUTED,
         StringAlignmentNear, StringAlignmentNear, true);

    Text(g, L"原工具公式保留；当前经验的处理已修正为“从总需求中扣除”。",
         RectF(lr.X + 22, lr.Y + 446, lr.Width - 44, 28), g_fTiny, C_FAINT,
         StringAlignmentNear, StringAlignmentNear, true);

    // small Q&A block keeps the lower half of the card useful
    RectF qa(lr.X + 22, lr.Y + 480, lr.Width - 44, 86);
    FillRound(g, qa, 14, Color(255, 247, 251, 255));
    StrokeRound(g, qa, 14, Color(255, 228, 238, 249), 1);
    Text(g, L"小问答", RectF(qa.X + 14, qa.Y + 6, 120, 16), g_fTinyBold, C_BLUE_DARK);
    Text(g, L"Q  低星角色也能升到 100 吗？", RectF(qa.X + 14, qa.Y + 22, qa.Width - 28, 14),
         g_fTiny, C_INK_SOFT);
    Text(g, L"A  不能。上限为 2★10 / 3★20 / 4★30 / 5★100。",
         RectF(qa.X + 14, qa.Y + 36, qa.Width - 28, 14), g_fTiny, C_MUTED);
    Text(g, L"Q  为什么礼物数比手算少？", RectF(qa.X + 14, qa.Y + 52, qa.Width - 28, 14),
         g_fTiny, C_INK_SOFT);
    Text(g, L"A  当前等级经验已计入进度，会被扣除。",
         RectF(qa.X + 14, qa.Y + 66, qa.Width - 28, 14), g_fTiny, C_MUTED);

    UIRect action = g_rHelpAction;
    bool hover = g_hover == 70;
    GradientRect(g, action.R(), 12, hover ? Color(255, 93, 175, 230) : Color(255, 71, 157, 219),
                 hover ? Color(255, 38, 120, 193) : Color(255, 38, 113, 184),
                 LinearGradientModeHorizontal);
    Text(g, L"回到礼物计算", action.R(), g_fSmallBold, C_WHITE,
         StringAlignmentCenter, StringAlignmentCenter);

    // right card
    RectF rr = g_rHelpRight.R();
    Panel(g, rr, 22, C_CARD, C_LINE);
    SectionBadge(g, rr.X + 22, rr.Y + 17, L"05");
    Text(g, L"数据卡", RectF(rr.X + 58, rr.Y + 11, 180, 26), g_fH3, C_INK);
    Text(g, L"本工具使用的数值与假设", RectF(rr.X + 58, rr.Y + 33, 280, 16), g_fTiny, C_MUTED);

    // level summary
    RectF lv(rr.X + 22, rr.Y + 62, rr.Width - 44, 60);
    FillRound(g, lv, 13, Color(255, 247, 251, 255));
    Text(g, L"Lv.1 → Lv.100", RectF(lv.X + 16, lv.Y + 9, 200, 18), g_fSmallBold, C_INK);
    Text(g, L"共 240,225 EXP", RectF(lv.X + 16, lv.Y + 30, 200, 24), g_fNum, C_BLUE_DARK);
    Text(g, L"星级上限 10 / 20 / 30 / 100", RectF(lv.X + 220, lv.Y + 13, 180, 34),
         g_fTiny, C_MUTED, StringAlignmentFar, StringAlignmentCenter);

    // gift table
    float y = rr.Y + 142;
    Text(g, L"单件礼物效率", RectF(rr.X + 22, y, 200, 18), g_fTinyBold, C_GOLD_DARK);
    y += 24;
    for (int i = 0; i < 8; ++i) {
        float col = (i % 2 == 0) ? 0.0f : 1.0f;
        float row = (float)(i / 2);
        float x = rr.X + 22 + col * 208;
        float yy = y + row * 40;
        FillRound(g, RectF(x, yy, 196, 34), 9, i % 2 == 0 ? Color(255, 249, 252, 255)
                                                          : Color(255, 253, 249, 255));
        Text(g, ITEMS[i].name, RectF(x + 10, yy, 120, 34), g_fSmall, C_INK,
             StringAlignmentNear, StringAlignmentCenter);
        std::wstring v = (ITEMS[i].kind == 3) ? L"≈32.5" : Num((long long)ITEMS[i].exp);
        Text(g, v + L" EXP", RectF(x + 128, yy, 58, 34), g_fTinyBold, C_BLUE_DARK,
             StringAlignmentFar, StringAlignmentCenter);
    }

    y += 4 * 40 + 12;
    Text(g, L"达成天数假设", RectF(rr.X + 22, y, 220, 18), g_fTinyBold, C_GOLD_DARK);
    y += 22;
    Text(g, L"· 每月 2 次活动、2 次决战、1 次制约接触作战\n  合计 8 个紫色礼物 + 80 个普通礼物\n"
            L"· 课程表 32.5 EXP × 175/230 出现率\n· 制造每次 2.45 普通 + 0.32 紫色期望\n"
            L"· 未实装角色不计摸头与课程表",
         RectF(rr.X + 22, y, rr.Width - 44, 112), g_fSmall, C_INK_SOFT,
         StringAlignmentNear, StringAlignmentNear, true);

    y += 126;
    Line(g, rr.X + 22, y, rr.X + rr.Width - 22, y, Color(255, 237, 232, 222), 1);
    Text(g, L"这是非官方粉丝工具，与 NEXON / Yostar 无关。\n游戏内数据可能随版本调整，结果仅供参考。",
         RectF(rr.X + 22, y + 12, rr.Width - 44, 54), g_fTiny, C_FAINT,
         StringAlignmentNear, StringAlignmentNear, true);

    Star(g, rr.X + 30, y + 92, 6, C_GOLD);
    Text(g, L"建议：活动紫礼优先补足；课程表与摸头是零成本日常来源。",
         RectF(rr.X + 44, y + 82, rr.Width - 66, 20), g_fTiny, C_MUTED,
         StringAlignmentNear, StringAlignmentCenter);
}

// =============================================================================
//  Hit testing
// =============================================================================
static int HitTest(float mx, float my) {
    if (g_rClose.Contains(mx, my)) return 2;
    if (g_rMin.Contains(mx, my)) return 1;

    if (my < TITLE_H) return 0;

    for (int i = 0; i < 3; ++i) {
        if (g_rNav[i].Contains(mx, my)) return 100 + i;
    }

    if (g_page == PAGE_CALC) {
        for (int i = 0; i < 3; ++i) {
            UIRect p = g_rPreset[i];
            p.x += g_rInputCard.x; p.y += g_rInputCard.y;
            if (p.Contains(mx, my)) return 10 + i;
        }
        UIRect b = g_rCalcButton;
        b.x += g_rInputCard.x; b.y += g_rInputCard.y;
        if (b.Contains(mx, my)) return 20;
        if (ResetButtonScreenRect().Contains(mx, my)) return 8;
        if (CopyButtonScreenRect().Contains(mx, my)) return 30;
        if (PlanLinkButtonScreenRect().Contains(mx, my)) return 31;

        for (int i = 0; i < 3; ++i) {
            if (FieldScreenRect(i).Contains(mx, my)) return 300 + i;
        }
    } else if (g_page == PAGE_PLAN) {
        if (ToggleScreenRect().Contains(mx, my)) return 40;
        for (int i = 0; i < 3; ++i) {
            if (CraftScreenRect(i).Contains(mx, my)) return 50 + i;
        }
        if (PlanButtonScreenRect().Contains(mx, my)) return 60;
        for (int i = 3; i < 8; ++i) {
            if (FieldScreenRect(i).Contains(mx, my)) return 300 + i;
        }
    } else if (g_page == PAGE_HELP) {
        if (g_rHelpAction.Contains(mx, my)) return 70;
    }
    return 0;
}

static void SetPage(int page) {
    if (page < 0 || page > 2 || page == g_page) return;
    g_page = page;
    g_hover = 0;
    PositionEdits();
    if (page == PAGE_PLAN) {
        if (g_calc.valid) CalculatePlan(false);
    }
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static void ResetCalculator() {
    SetWindowTextW(EditHandle(ID_EDIT_CUR), L"1");
    SetWindowTextW(EditHandle(ID_EDIT_EXP), L"0");
    SetWindowTextW(EditHandle(ID_EDIT_TARGET), L"100");
    g_displayRemaining = 0;
    Recalculate();
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static void HandlePrimaryAction() {
    if (g_page == PAGE_CALC) {
        Recalculate();
        if (g_calc.valid) {
            InvalidateRect(g_hwnd, nullptr, FALSE);
        } else {
            InvalidateRect(g_hwnd, nullptr, FALSE);
        }
    } else if (g_page == PAGE_PLAN) {
        CalculatePlan(true);
        InvalidateRect(g_hwnd, nullptr, FALSE);
    }
}

// =============================================================================
//  Painting
// =============================================================================
static void Paint(HDC hdc) {
    RECT rc;
    GetClientRect(g_hwnd, &rc);
    int w = rc.right - rc.left;
    int h = rc.bottom - rc.top;
    if (w <= 0 || h <= 0) return;

    HDC mem = CreateCompatibleDC(hdc);
    HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
    HGDIOBJ old = SelectObject(mem, bmp);

    {
        Graphics g(mem);
        g.SetSmoothingMode(SmoothingModeAntiAlias);
        g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit);
        g.SetPixelOffsetMode(PixelOffsetModeHighQuality);
        g.SetInterpolationMode(InterpolationModeHighQualityBicubic);
        g.ScaleTransform(g_scale, g_scale);

        // background
        LinearGradientBrush bg(RectF(0, 0, (float)BASE_W, (float)BASE_H),
                               C_BG_TOP, C_BG_BOTTOM, LinearGradientModeVertical);
        g.FillRectangle(&bg, RectF(0, 0, (float)BASE_W, (float)BASE_H));

        // soft glows
        SolidBrush glow1(Color(16, 142, 209, 241));
        g.FillEllipse(&glow1, RectF(1020, 40, 300, 300));
        SolidBrush glow2(Color(12, 245, 171, 190));
        g.FillEllipse(&glow2, RectF(-120, 640, 380, 380));

        // faint halftone pattern in content area
        for (int i = 0; i < 19; ++i) {
            for (int j = 0; j < 7; ++j) {
                Dot(g, (float)(1040 + i * 12), (float)(160 + j * 12), 1.0f, Color(22, 100, 158, 200));
            }
        }

        // big halo rings
        Halo(g, 1120, 90, 205, 80, Color(36, 247, 196, 85), 0.8f);
        Halo(g, 1120, 90, 170, 56, Color(26, 247, 196, 85), 0.6f);

        DrawSidebar(g);
        DrawTitleBar(g);

        if (g_page == PAGE_CALC) DrawCalculator(g);
        else if (g_page == PAGE_PLAN) DrawPlanner(g);
        else DrawHelp(g);
    }

    BitBlt(hdc, 0, 0, w, h, mem, 0, 0, SRCCOPY);
    SelectObject(mem, old);
    DeleteObject(bmp);
    DeleteDC(mem);
}

// =============================================================================
//  Window procedure
// =============================================================================
static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE: {
        g_hwnd = hwnd;
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, 0);
        CreateBrushes();
        CreateEditFonts();
        CreateEdits();
        BuildLayout();
        PositionEdits();
        Recalculate();
        g_displayRemaining = (double)g_calc.remaining;
        CalculatePlan(false);
        return 0;
    }
    case WM_ERASEBKGND:
        return 1;

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        Paint(hdc);
        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_SIZE: {
        if (wp == SIZE_MINIMIZED) return 0;
        BuildLayout();
        PositionEdits();
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;
    }

    case WM_GETMINMAXINFO: {
        // fixed-size window
        MINMAXINFO* info = (MINMAXINFO*)lp;
        if (g_winW > 0 && g_winH > 0) {
            info->ptMinTrackSize.x = info->ptMaxTrackSize.x = g_winW;
            info->ptMinTrackSize.y = info->ptMaxTrackSize.y = g_winH;
        }
        return 0;
    }

    case WM_MOUSEMOVE: {
        float mx = GET_X_LPARAM(lp) / g_scale;
        float my = GET_Y_LPARAM(lp) / g_scale;
        int hit = HitTest(mx, my);
        if (hit != g_hover) {
            g_hover = hit;
            InvalidateRect(hwnd, nullptr, FALSE);
        }
        if (!g_trackingMouse) {
            TRACKMOUSEEVENT tme = { sizeof(tme), TME_LEAVE, hwnd, 0 };
            TrackMouseEvent(&tme);
            g_trackingMouse = true;
        }
        if (hit >= 300 || (hit >= 10 && hit <= 12)) {
            SetCursor(LoadCursorW(nullptr, IDC_IBEAM));
        } else if (hit != 0) {
            SetCursor(LoadCursorW(nullptr, IDC_HAND));
        } else {
            SetCursor(LoadCursorW(nullptr, IDC_ARROW));
        }
        return 0;
    }

    case WM_MOUSELEAVE:
        g_trackingMouse = false;
        if (g_hover != 0) {
            g_hover = 0;
            InvalidateRect(hwnd, nullptr, FALSE);
        }
        return 0;

    case WM_SETCURSOR:
        if (LOWORD(lp) == HTCLIENT) {
            POINT pt;
            GetCursorPos(&pt);
            ScreenToClient(hwnd, &pt);
            int hit = HitTest(pt.x / g_scale, pt.y / g_scale);
            if (hit != 0) {
                SetCursor(LoadCursorW(nullptr, hit >= 300 ? IDC_IBEAM : IDC_HAND));
                return TRUE;
            }
        }
        break;

    case WM_LBUTTONDOWN: {
        float mx = GET_X_LPARAM(lp) / g_scale;
        float my = GET_Y_LPARAM(lp) / g_scale;
        int hit = HitTest(mx, my);
        if (my < TITLE_H && hit == 0) {
            ReleaseCapture();
            SendMessageW(hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            return 0;
        }
        if (hit == 0) {
            SetFocus(hwnd);
            return 0;
        }
        if (hit >= 300) {
            int idx = hit - 300;
            int ids[8] = { ID_EDIT_CUR, ID_EDIT_TARGET, ID_EDIT_EXP, ID_EDIT_PATS,
                           ID_EDIT_M1, ID_EDIT_M2, ID_EDIT_N1, ID_EDIT_N2 };
            if (idx >= 0 && idx < 8) {
                HWND ed = EditHandle(ids[idx]);
                SetFocus(ed);
                SendMessageW(ed, EM_SETSEL, 0, -1);
            }
            return 0;
        }
        switch (hit) {
        case 1: SendMessageW(hwnd, WM_SYSCOMMAND, SC_MINIMIZE, 0); break;
        case 2: PostMessageW(hwnd, WM_CLOSE, 0, 0); break;
        case 100: SetPage(PAGE_CALC); break;
        case 101: SetPage(PAGE_PLAN); break;
        case 102: SetPage(PAGE_HELP); break;
        case 8: ResetCalculator(); break;
        case 10:
            SetWindowTextW(EditHandle(ID_EDIT_CUR), L"1");
            SetWindowTextW(EditHandle(ID_EDIT_EXP), L"0");
            SetWindowTextW(EditHandle(ID_EDIT_TARGET), L"100");
            Recalculate(); InvalidateRect(hwnd, nullptr, FALSE); break;
        case 11:
            SetWindowTextW(EditHandle(ID_EDIT_CUR), L"30");
            SetWindowTextW(EditHandle(ID_EDIT_EXP), L"0");
            SetWindowTextW(EditHandle(ID_EDIT_TARGET), L"50");
            Recalculate(); InvalidateRect(hwnd, nullptr, FALSE); break;
        case 12:
            SetWindowTextW(EditHandle(ID_EDIT_CUR), L"90");
            SetWindowTextW(EditHandle(ID_EDIT_EXP), L"0");
            SetWindowTextW(EditHandle(ID_EDIT_TARGET), L"100");
            Recalculate(); InvalidateRect(hwnd, nullptr, FALSE); break;
        case 20: HandlePrimaryAction(); break;
        case 30: CopySummary(); break;
        case 31: SetPage(PAGE_PLAN); break;
        case 40:
            g_implemented = !g_implemented;
            EnableWindow(EditHandle(ID_EDIT_PATS), g_implemented ? TRUE : FALSE);
            if (g_page == PAGE_PLAN) CalculatePlan(false);
            InvalidateRect(hwnd, nullptr, FALSE); break;
        case 50: g_craft = 0; if (g_page == PAGE_PLAN) CalculatePlan(false); InvalidateRect(hwnd, nullptr, FALSE); break;
        case 51: g_craft = 3; if (g_page == PAGE_PLAN) CalculatePlan(false); InvalidateRect(hwnd, nullptr, FALSE); break;
        case 52: g_craft = 6; if (g_page == PAGE_PLAN) CalculatePlan(false); InvalidateRect(hwnd, nullptr, FALSE); break;
        case 60: HandlePrimaryAction(); break;
        case 70: SetPage(PAGE_CALC); break;
        default: break;
        }
        return 0;
    }

    case WM_COMMAND: {
        int id = LOWORD(wp);
        int code = HIWORD(wp);
        if (id >= ID_EDIT_BASE && id <= ID_EDIT_LAST) {
            if (code == EN_SETFOCUS || code == EN_KILLFOCUS) {
                InvalidateRect(hwnd, nullptr, FALSE);
            } else if (code == EN_CHANGE) {
                InvalidateRect(hwnd, nullptr, FALSE);
            }
        }
        return 0;
    }

    case WM_CTLCOLOREDIT: {
        HDC dc = (HDC)wp;
        HWND edit = (HWND)lp;
        if (!IsWindowEnabled(edit)) {
            SetTextColor(dc, RGB(160, 168, 180));
            SetBkColor(dc, RGB(243, 244, 246));
            return (LRESULT)g_disabledBrush;
        }
        bool focused = GetFocus() == edit;
        SetTextColor(dc, RGB(40, 54, 79));
        SetBkColor(dc, focused ? RGB(238, 248, 255) : RGB(246, 249, 253));
        return (LRESULT)(focused ? g_fieldFocusBrush : g_fieldBrush);
    }

    case WM_TIMER: {
        if (wp == TIMER_ANIM) {
            ULONGLONG now = GetTickCount64();
            double t = (double)(now - g_animStart) / 520.0;
            if (t >= 1.0) {
                g_displayRemaining = g_animTo;
                g_animating = false;
                KillTimer(hwnd, TIMER_ANIM);
            } else {
                double e = 1.0 - std::pow(1.0 - t, 3.0);
                g_displayRemaining = g_animFrom + (g_animTo - g_animFrom) * e;
            }
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        if (wp == TIMER_TOAST) {
            KillTimer(hwnd, TIMER_TOAST);
            g_toast.clear();
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        break;
    }

    case WM_APP_PRIMARY:
        HandlePrimaryAction();
        return 0;

    case WM_KEYDOWN:
        if (wp == VK_RETURN) { HandlePrimaryAction(); return 0; }
        if (wp == VK_ESCAPE) { SetFocus(hwnd); return 0; }
        break;

    case WM_CLOSE:
        DestroyWindow(hwnd);
        return 0;

    case WM_DESTROY:
        KillTimer(hwnd, TIMER_ANIM);
        KillTimer(hwnd, TIMER_TOAST);
        PostQuitMessage(0);
        return 0;

    case WM_DPICHANGED: {
        // Keep the app sharp when moving between monitors. Recompute scale and
        // keep the fixed design size centered in the suggested rectangle.
        int ndpi = HIWORD(wp);
        RECT* suggested = (RECT*)lp;
        g_dpi = ndpi;
        RECT wa;
        SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
        float baseScale = ndpi / 96.0f;
        float fit = std::min(1.0f, std::min((wa.right - wa.left - 24.0f) / (BASE_W * baseScale),
                                            (wa.bottom - wa.top - 24.0f) / (BASE_H * baseScale)));
        g_scale = baseScale * fit;
        g_winW = (int)std::lround(BASE_W * g_scale);
        g_winH = (int)std::lround(BASE_H * g_scale);
        int x = suggested->left + ((suggested->right - suggested->left) - g_winW) / 2;
        int y = suggested->top + ((suggested->bottom - suggested->top) - g_winH) / 2;
        SetWindowPos(hwnd, nullptr, x, y, g_winW, g_winH, SWP_NOZORDER | SWP_NOACTIVATE);
        CreateEditFonts();
        BuildLayout();
        PositionEdits();
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;
    }
    }

    return DefWindowProcW(hwnd, msg, wp, lp);
}

// =============================================================================
//  Entry point
// =============================================================================
static int GetSystemDpiSafe() {
    HMODULE user32 = GetModuleHandleW(L"user32.dll");
    if (user32) {
        typedef UINT (WINAPI* GetDpiForSystemFn)();
        auto fn = (GetDpiForSystemFn)GetProcAddress(user32, "GetDpiForSystem");
        if (fn) return (int)fn();
    }
    HDC dc = GetDC(nullptr);
    int dpi = GetDeviceCaps(dc, LOGPIXELSX);
    ReleaseDC(nullptr, dc);
    return dpi > 0 ? dpi : 96;
}

static void EnableDpiAwareness() {
    HMODULE user32 = GetModuleHandleW(L"user32.dll");
    if (user32) {
        typedef BOOL (WINAPI* SetDpiContextFn)(HANDLE);
        auto fn = (SetDpiContextFn)GetProcAddress(user32, "SetProcessDpiAwarenessContext");
        if (fn) {
            if (fn((HANDLE)-4)) return; // DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2
        }
    }
    SetProcessDPIAware();
}

int APIENTRY wWinMain(HINSTANCE hInstance, HINSTANCE, LPWSTR, int nCmdShow) {
    g_hinst = hInstance;
    EnableDpiAwareness();

    GdiplusStartupInput gdiInput;
    if (GdiplusStartup(&g_gdiplusToken, &gdiInput, nullptr) != Ok) return 1;

    g_dpi = GetSystemDpiSafe();
    RECT wa;
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
    float baseScale = g_dpi / 96.0f;
    float fit = std::min(1.0f, std::min((wa.right - wa.left - 24.0f) / (BASE_W * baseScale),
                                        (wa.bottom - wa.top - 24.0f) / (BASE_H * baseScale)));
    g_scale = baseScale * fit;
    g_winW = (int)std::lround(BASE_W * g_scale);
    g_winH = (int)std::lround(BASE_H * g_scale);

    // load embedded artwork
    g_imgApp = LoadPngResource(IDR_APP_PNG);
    g_imgHero = LoadPngResource(IDR_HERO_PNG);
    g_imgSidebar = LoadPngResource(IDR_SIDEBAR);
    g_imgItems[0] = LoadPngResource(IDR_ITEM_PAT);
    g_imgItems[1] = LoadPngResource(IDR_ITEM_20);
    g_imgItems[2] = LoadPngResource(IDR_ITEM_40);
    g_imgItems[3] = LoadPngResource(IDR_ITEM_60);
    g_imgItems[4] = LoadPngResource(IDR_ITEM_120);
    g_imgItems[5] = LoadPngResource(IDR_ITEM_180);
    g_imgItems[6] = LoadPngResource(IDR_ITEM_240);
    g_imgItems[7] = LoadPngResource(IDR_ITEM_COURSE);

    CreateFonts();
    BuildLayout();

    WNDCLASSEXW wc = {};
    wc.cbSize = sizeof(wc);
    wc.style = CS_HREDRAW | CS_VREDRAW | CS_DROPSHADOW;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIconW(hInstance, MAKEINTRESOURCEW(IDI_APP));
    wc.hIconSm = LoadIconW(hInstance, MAKEINTRESOURCEW(IDI_APP));
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hbrBackground = nullptr;
    wc.lpszClassName = L"BlueArchiveAffectionCalculator";
    if (!RegisterClassExW(&wc)) return 1;

    int x = wa.left + ((wa.right - wa.left) - g_winW) / 2;
    int y = wa.top + ((wa.bottom - wa.top) - g_winH) / 2;

    g_hwnd = CreateWindowExW(WS_EX_APPWINDOW, wc.lpszClassName, L"蔚蓝档案 · 好感计算器",
                             WS_POPUP | WS_MINIMIZEBOX | WS_SYSMENU | WS_CLIPCHILDREN,
                             x, y, g_winW, g_winH, nullptr, nullptr, hInstance, nullptr);
    if (!g_hwnd) return 1;

    // Windows 11 rounded corners + border color, when available.
    HMODULE dwm = LoadLibraryW(L"dwmapi.dll");
    if (dwm) {
        g_dwmSetWindowAttribute = (DwmSetWindowAttributeFn)GetProcAddress(dwm, "DwmSetWindowAttribute");
        if (g_dwmSetWindowAttribute) {
            DWORD pref = 2; // DWMWCP_ROUND
            g_dwmSetWindowAttribute(g_hwnd, 33, &pref, sizeof(pref));
            COLORREF border = RGB(214, 208, 197);
            g_dwmSetWindowAttribute(g_hwnd, 34, &border, sizeof(border));
        }
    }

    ShowWindow(g_hwnd, nCmdShow);
    UpdateWindow(g_hwnd);

    // Let the first paint settle before the subtle entrance fade.
    AnimateWindow(g_hwnd, 160, AW_BLEND);

    HACCEL accel = nullptr;
    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        if (accel && TranslateAcceleratorW(g_hwnd, accel, &msg)) continue;
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    for (auto*& img : g_imgItems) { delete img; img = nullptr; }
    delete g_imgApp; g_imgApp = nullptr;
    delete g_imgHero; g_imgHero = nullptr;
    delete g_imgSidebar; g_imgSidebar = nullptr;
    delete g_fH1; delete g_fH2; delete g_fH3; delete g_fBody; delete g_fBodyBold;
    delete g_fSmall; delete g_fSmallBold; delete g_fTiny; delete g_fTinyBold;
    delete g_fNum; delete g_fNumBig; delete g_fNumHuge; delete g_fButton; delete g_fBrand;
    if (g_editFontBig) DeleteObject(g_editFontBig);
    if (g_editFontMed) DeleteObject(g_editFontMed);
    if (g_editFontSmall) DeleteObject(g_editFontSmall);
    if (g_fieldBrush) DeleteObject(g_fieldBrush);
    if (g_fieldFocusBrush) DeleteObject(g_fieldFocusBrush);
    if (g_disabledBrush) DeleteObject(g_disabledBrush);
    GdiplusShutdown(g_gdiplusToken);
    return 0;
}



